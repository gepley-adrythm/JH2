# Core Content Modules: Blog, FAQ, Glossary

The content engine. These three modules are the foundation every content-driven site should build **before** anything business-specific. Together they form the pillar/cluster system from `02-SEO-ARCHITECTURE.md`: the Blog holds your **pillars**, the FAQ holds the **clusters**, and the Glossary holds the **shared vocabulary** they all reference.

Build them in this order: **Glossary, then Blog pillars, then FAQ clusters**, then keep all three growing together. Replace bracketed placeholders with your own.

> Before writing any content in these modules, read the two companion guides:
> `SEO-FAQ-QUALITY-STANDARDS.md` (the quality bar and format decision tree) and
> `SEO-FAQ-IDEA-SOURCING.md` (how to find topics). They are written for FAQ but
> apply to all three modules.

---

## Why these three, and why this order

Each format answers a different kind of search intent. Trying to answer all of them with one format is the most common content mistake.

```
New content idea
       │
       ▼
Is it a definition / "what does X mean"?  ──YES──▶  GLOSSARY  (150-300 words)
       │ NO
       ▼
Can it be fully answered in one focused
question?                                 ──YES──▶  FAQ       (500-1,500 words)
       │ NO
       ▼
Is it a broad topic needing depth and
multiple sub-sections?                    ──YES──▶  BLOG      (1,500-3,000 words, pillar)
```

(This is the same decision tree as the quality standards guide. Always run it before writing.)

**Order matters:**
1. **Glossary first** establishes the vocabulary everything else will link to and reference.
2. **Blog pillars next** stake out your major topics in depth and become the hubs.
3. **FAQ clusters last (and forever)** capture the long tail of real questions and link up to the pillars.

---

## Module 1: Glossary (shared vocabulary)

**Purpose:** short, authoritative definitions of the terms your industry and customers use. This is programmatic SEO at scale: many small pages, each owning one term.

- **Format:** 150 to 300 words per term. A clear definition first, then a sentence or two of context, then a link to deeper content (the FAQ or pillar that explains it).
- **Routes:** a hub at `/glossary` (searchable, filterable by category) and a page per term at `/glossary/[slug]`.
- **Schema:** `DefinedTerm` per term, `DefinedTermSet` for the collection (see `02-SEO-ARCHITECTURE.md`).
- **Data:** keep all terms in a single source (a seed file or CMS collection): `id`, `term`, `slug`, `definition`, `category`, and `relatedTerms[]` / `relatedFaqIds[]` for cross-linking.
- **Why first:** definitions are the atoms of your topic. Once a term exists, every blog post and FAQ can link to it instead of re-explaining it, which keeps longer content focused and spreads internal links.

## Module 2: Blog (pillars + supporting guides)

**Purpose:** long-form, comprehensive guides. These are your **pillars**, the pages that target your biggest head terms and anchor each topic cluster.

- **Format:** 1,500 to 3,000 words, structured into clear H2/H3 sections with a table of contents. Written at a general-audience reading level (roughly 7th to 8th grade) so it is genuinely useful, not academic.
- **Routes:** a listing at `/resources` (or `/blog`) and a post per slug at `/resources/blog/[slug]`.
- **Schema:** `Article` or `BlogPosting`. A pillar may also embed an `FAQPage` block if it includes an inline FAQ section.
- **Structured content blocks:** model post content as an array of typed blocks rather than one giant HTML blob: `heading`, `subheading`, `paragraph`, `list-item`, `callout`, `cta`, `chart`, and an inline `faq` block that pulls in existing FAQ items by ID. This keeps content portable, consistently styled, and easy to validate.
- **Data fields per post:** `id`, `title`, `slug`, `category`, `summary`, `tags[]`, `heroImage`, `metaTitle`, `metaDescription`, `relatedServiceIds[]`, `relatedFaqIds[]` (required, since this is how the cluster links back), `publishedDate`, `featured`, `active`, and the `content[]` blocks.
- **Calls to action:** every pillar should drive toward conversion. A reliable pattern is two CTAs, one mid-article and one near the end, pointing at the relevant service or contact step.
- **Cross-linking:** a pillar links **down** to its FAQs (via `relatedFaqIds` and inline FAQ blocks) and glossary terms, **across** to the related service page, and **out** to a call to action.

## Module 3: FAQ (the long-tail clusters)

**Purpose:** focused answers to single, real questions. This is where you capture the enormous long tail of "how much," "do I need," "what happens if," and "X vs Y" searches. It is also where you earn AI citations, because answer engines love a clean question-and-answer.

- **Format:** 500 to 1,500 words, each page answering **one intent**. The non-negotiable rule (from `SEO-FAQ-QUALITY-STANDARDS.md`): **one intent, one page.** If two questions satisfy the same need, merge them.
- **Routes:** a hub at `/faq`, a page per question at `/faq/[slug]`, and **topic pages** at `/faq/topics/[slug]` that group related questions into a browsable cluster.
- **Schema:** use `FAQPage` for your editorial FAQ pages, whether a page holds one question or many. It is the correct type for answers the site writes itself. Reserve `QAPage` for genuine user-submitted Q&A (forum-style pages where visitors contribute answers), which most marketing sites do not have. Do not put two FAQ schema blocks on one page.
- **Data fields per item:** `id`, `question`, `slug`, `category`, `answer` (the full, visible answer, which is also what your `FAQPage` markup uses), an optional `shortAnswer` (a concise summary for the meta description and for AI-citation snippets; keep it consistent with the visible answer and never let it assert anything the page does not), `metaDescription`, and `relatedFaqIds[]` / `relatedServiceIds[]`.
- **Topic pages are the cluster glue:** a topic page gathers the FAQs for one sub-subject and, when a pillar exists, opens with a "start with the full guide" link to that pillar. When no pillar exists yet, it simply omits that callout. Build the topic page anyway and add the pillar link later.
- **Guard against duplication:** before adding any FAQ, check it against what you already publish. A duplicate-intent checker (even a simple search of existing questions) prevents two pages from cannibalizing each other. Maintain a **content intent registry**, a running list of every published question/topic, so contributors can see overlap before they write.

---

## How the three interlink (the compounding effect)

The value is not in the three modules separately. It is in the web between them:

```
   BLOG PILLAR  ──links down──▶  FAQ items + Glossary terms
        ▲                              │
        └──────── links up ───────────┘
   GLOSSARY term ──links out──▶  the FAQ / pillar that explains it
   SERVICE page  ──links to───▶  its pillar + its FAQs
```

- A reader landing on a glossary term can go deeper into the pillar.
- A reader on an FAQ can jump to the full guide or to the service that solves their problem.
- A reader on a pillar can drill into any specific question.
- Search engines see a tightly interlinked topic and treat you as an authority.

Every new piece of content should add at least one link in **each** direction. Content that links to nothing, or that nothing links to, is wasted effort.

---

## The content intent registry (do this from day one)

Keep one file or table listing every published piece across all three modules: its format, its intent/question, and its URL. Before writing anything new, check the registry for overlap. This single habit prevents the three SEO killers covered in `SEO-FAQ-QUALITY-STANDARDS.md`: duplicate intent, thin content, and keyword cannibalization. It becomes essential the moment you add business-specific modules (`04-BUILDING-NEW-MODULES.md`), because every new module competes for some of the same keywords.

---

## Quality bar (applies to all three)

- Run the **format decision tree** before writing. Pick glossary vs. FAQ vs. blog deliberately.
- **One intent per page.** Merge overlapping ideas instead of spawning thin duplicates.
- Write at a **general-audience reading level**; explain, do not lecture.
- **Source topics from real questions** (see `SEO-FAQ-IDEA-SOURCING.md`), not from guesswork.
- **Cross-link** every new page into the cluster in both directions.
- **Register** every new page in the content intent registry.

With these three modules healthy and interlinked, you have a content core that compounds. Only then should you build the business-specific modules in `04-BUILDING-NEW-MODULES.md`.
