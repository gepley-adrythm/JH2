# Backend and Stack Setup

Doc `05-FRAMEWORKS.md` decided *how each page renders*. This doc decides *what
you stand up to serve those pages*: the framework and supporting stack, the data
layer behind your content, how media is served, and how configuration and
secrets are handled.

It stays framework-agnostic, but it is opinionated about shape. The patterns here
are the ones that repeatedly hold up for a content-and-SEO site at scale.
Replace bracketed placeholders like `[YOUR BRAND]` with your own.

---

## 1. The principle: a thin backend behind a content-first frontend

For a content-driven marketing site, the backend should do as little as possible.
Its only real jobs are:

- **Persist content** (read it at build or request time).
- **Call external services** (CMS, search, email, payments) and keep their
  secrets server-side.

Everything else (layout, rendering, interactivity) lives in the frontend and the
rendering model you chose in `05-FRAMEWORKS.md`. A fat backend is a sign that
logic that belongs in static generation or the client has leaked server-side.
Keep request handlers thin: validate input, call the data layer, return.

---

## 2. The reference stack

You do not have to use these exact tools. Use the table to fill each **role**;
the role is what matters, the tool is replaceable.

| Role | What it does | Common choices |
| --- | --- | --- |
| **Framework** | Routing, rendering (SSG/ISR/SSR), metadata, image handling | Next.js, Astro, SvelteKit, Nuxt, Remix |
| **Language** | Type safety across frontend and backend | TypeScript (strongly recommended) |
| **Styling** | Design system, theming, dark mode | Tailwind CSS, CSS Modules, vanilla-extract |
| **UI primitives** | Accessible base components | A headless component library plus your own design layer |
| **Data layer** | Typed access to your content store | An ORM or query builder over your database |
| **Database** | System of record for content | A relational database (Postgres is a safe default) |
| **Media delivery** | Image and asset optimization at the edge | A CDN with on-the-fly image transforms |
| **Data fetching/cache (client)** | Cache and revalidate any client-side reads | A query/cache library for the client |

Pick the framework first (using the `05-FRAMEWORKS.md` checklist), then fill the
rest of the roles around it. The data layer and database choices below apply
regardless of which framework you land on.

---

## 3. Data model first: one typed source of truth

Before writing routes or components, define the **shape of your content**. This
is the single highest-leverage decision in the backend.

- Define each content type once, in a **typed schema** (table definitions plus
  derived insert and select types). Every other layer (routes, sitemaps,
  navigation, internal links, structured data) reads from these types. When the
  shape changes, the type change ripples out and the compiler shows you every
  place to update.
- Keep the model **as simple as the content needs**. Do not add bookkeeping
  fields (timestamps, soft-delete flags, audit columns) unless something
  actually reads them. Every unused column is drift waiting to happen.
- Give every record a stable `id` and a URL `slug`. Routes and internal links
  reference records **by id**, never by a pasted URL string (see
  `04-BUILDING-NEW-MODULES.md`).
- Arrays and relations belong in the schema, not stringified in a text column.

> Rule: the schema is the contract between frontend and backend. Write it before
> the first route, and treat any change to it as a deliberate, traced edit.

---

## 4. The content pipeline: seed to database

Content for a marketing site is mostly **authored once and read constantly**.
A reliable pattern for this is **seed-to-database**:

1. Author content as typed **seed files** in the repo (or in a CMS collection).
   These are reviewable in pull requests and version-controlled.
2. On server start (or in a one-shot migration step), **load seeds into the
   database** if they are not already present.
3. Make the load **idempotent and non-blocking**: skip seeding when the row
   count already matches the expected count, so startup stays fast and a restart
   never duplicates rows.
4. The application reads from the database, not from the seed files directly. The
   database is the runtime system of record; the seeds are the authoring source.

This gives you the authoring ergonomics of files with the query power of a
database. For content that genuinely changes at runtime (user submissions, live
inventory), write to the database directly and skip the seed step for those
tables.

If you use a hosted CMS instead of seed files, the same separation holds: the CMS
is the authoring source, and your framework reads it at build time (SSG/ISR) or
request time (SSR) per the rendering model you chose.

---

## 5. Optional: semantic search and AI retrieval

If the site is large enough that visitors (or your own related-content features)
need meaning-based search rather than keyword matching, add a **vector search**
layer. Treat it as optional; do not build it before the core content exists.

The shape that works well:

- Generate an **embedding** for each content record (title plus body) using an
  embedding model, and store the vector alongside the record (a vector column or
  a dedicated embeddings table covering every content type).
- Index the vectors for fast nearest-neighbor lookup.
- Refresh embeddings on the same schedule you refresh content, so search never
  drifts from what is published.

This same embedding store powers "related articles," "people also ask," and
on-site semantic search from one source. Build it only once keyword search and
internal linking are no longer enough.

**AI discoverability (cheap, high value):** expose a plain-text index of your
content for AI crawlers (for example a `/llms.txt` route that lists your key
pages, and a fuller variant with summaries), generated from the same data layer
and cached. It costs little and makes your content easy for answer engines to
ingest. See `02-SEO-ARCHITECTURE.md` for how this fits the SEO surfaces.

---

## 6. Media and images: let the CDN do the optimizing

How you serve images is a backend decision with outsized performance impact. The
single most important rule:

> **Upload the highest-quality original once. Let the CDN resize, compress, and
> format-convert per request. Never pre-compress before upload.**

Why this matters: if you shrink or re-encode an image before it reaches the CDN,
you have permanently thrown away pixels the CDN could have kept, and you cannot
get them back. The CDN can always make a smaller variant from a large master; it
can never reconstruct detail from a small one.

The serving pattern:

- Keep **one source path** per image. Do not ship the same image as both `.jpg`
  and `.webp` on disk; let the CDN pick the format per request (`format=auto`).
- Use your framework's image component so you get responsive `srcset`,
  lazy-loading, explicit dimensions (which prevent layout shift), and an LCP
  `priority` hint for the hero. Do not hand-roll `<img>` for content images.
- Route every image through **one loader/transform path**. Do not hand-write
  CDN transform URLs in markup; that fragments the edge cache and bypasses your
  responsive variants.
- Pick a small **whitelist of quality values** (for example 75, 85, 90, 95) and
  stick to it. Bespoke per-image quality values create a unique cache entry per
  render and shred your edge cache hit rate.
- Keep a **disaster-recovery copy** of every production image somewhere off the
  CDN (object storage or a backup drive), plus a manifest mapping local path to
  CDN id. The repo is not your backup; the backup is your backup.

Do not run local image optimizers (`sharp`, `imagemin`, `squoosh`, `cwebp`, and
similar) as part of the **serving** path. Local image processing belongs only in
a one-time **generation/upscale** step that produces the master you upload, never
in the request hot path.

---

## 7. Configuration and secrets

- **Never hardcode contact details, brand strings, or environment values** in
  components. Import brand and contact info from one config module (the nav kit
  in `components/navConfig.ts` is an example of this pattern for the header).
- **Never commit secrets.** API keys, tokens, and connection strings live in
  environment variables, injected at runtime, read **server-side only**. Use your
  platform's secret store.
- Only values that are genuinely safe in the browser may be exposed to the
  client, and they must be explicitly marked as public per your framework's
  convention. When in doubt, keep it server-side and proxy through a thin route.
- Centralize anything used in more than one place (brand name, base URL, support
  email, social handles) so a rebrand is a one-file change.

---

## 8. Setup order (do it in this sequence)

1. **Choose the framework and rendering models** (`05-FRAMEWORKS.md`).
2. **Define the typed data model** for your first content types (section 3).
3. **Stand up the database** and wire the data layer (ORM/query builder) to it.
4. **Author seed content** and the idempotent seed-to-database step (section 4).
5. **Build the routes** (hub plus detail) that read from the data layer, per
   `01-SITE-STRUCTURE.md` and `04-BUILDING-NEW-MODULES.md`.
6. **Wire media** through the CDN and your framework's image component
   (section 6).
7. **Add SEO surfaces**: metadata, JSON-LD, sitemap, robots (`02-SEO-ARCHITECTURE.md`).
8. **Confirm secrets and config** are centralized and server-side (section 7).
9. **Only later**, if needed, add semantic search and AI retrieval (section 5).

Once this is in place, read `07-FRAMEWORK-PATTERNS.md` for the rendering and SEO
patterns that keep every page shipping real HTML, which is the whole point of the
stack you just built.
