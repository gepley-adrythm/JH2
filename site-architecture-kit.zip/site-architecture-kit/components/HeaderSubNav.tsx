'use client';

/**
 * HeaderSubNav: the contextual sub-nav rail.
 *
 * Renders a single horizontal row of section children below the main header.
 * Show it on a section landing page (e.g. /services, /resources, /about) so the
 * visitor sees a persistent "where am I, what else is in here" map of the
 * current section. It is purely presentational and reads its entries from the
 * same `children` arrays defined in navConfig.ts.
 *
 * Routing note: this kit is written for the Next.js App Router (next/link +
 * usePathname). To use it elsewhere, swap `Link` for your router's link
 * component and `usePathname()` for the equivalent (react-router's
 * useLocation().pathname, etc.). Nothing else is framework-specific.
 */

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import type { SubNavItem } from './navConfig';
import { isNavActive, siteNav } from './navConfig';

interface HeaderSubNavProps {
  /** The section's children. Pass `item.children` from navConfig. */
  sections: SubNavItem[];
  /** Accessible label, e.g. "Resources sections". */
  ariaLabel: string;
  /** Test id prefix for the row container. */
  testId?: string;
}

export default function HeaderSubNav({ sections, ariaLabel, testId = 'header-subnav' }: HeaderSubNavProps) {
  const pathname = usePathname();
  const { theme } = siteNav;

  if (!sections.length) return null;

  return (
    <div
      data-testid={testId}
      className="w-full border-t"
      style={{ background: theme.bar, borderColor: theme.border }}
    >
      <nav
        aria-label={ariaLabel}
        className="mx-auto flex max-w-[1800px] flex-wrap items-center justify-center gap-x-6 gap-y-1 px-4 py-2 md:px-6 lg:px-10"
      >
        {sections.map((s) => {
          const active = isNavActive(pathname, s.href);
          const className = 'rounded px-1 py-1 text-[13px] font-semibold uppercase tracking-wide transition-opacity hover:opacity-100';
          const style = {
            color: active ? theme.accent : theme.barText,
            opacity: active ? 1 : 0.85,
            letterSpacing: '0.05em',
            borderBottom: active ? `2px solid ${theme.accent}` : '2px solid transparent',
          } as const;

          return s.external ? (
            <a
              key={s.id}
              href={s.href}
              target="_blank"
              rel="noopener noreferrer"
              data-testid={`${testId}-${s.id}`}
              className={className}
              style={style}
            >
              {s.label}
            </a>
          ) : (
            <Link
              key={s.id}
              href={s.href}
              data-testid={`${testId}-${s.id}`}
              className={className}
              style={style}
              aria-current={active ? 'page' : undefined}
            >
              {s.label}
            </Link>
          );
        })}
      </nav>
    </div>
  );
}
