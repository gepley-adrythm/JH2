'use client';

import { usePathname } from 'next/navigation';
import { useEffect, useRef } from 'react';

/**
 * Resets the scroll position to the top whenever the route changes.
 *
 * Without this, a client-side navigation can leave the new page scrolled to
 * wherever the previous page was, which looks broken and undercuts the
 * transition. It fires only on an actual path change, not on every render, so
 * hash/anchor changes within the same page are left alone.
 *
 * Tradeoff to know: because it scrolls on ANY path change, it also scrolls to
 * top on back/forward navigation to a different route, which overrides the
 * browser's native scroll restoration. That is usually what you want. If you
 * need to preserve scroll position on back/forward, gate the scroll on a
 * forward navigation (for example, skip it when a `popstate` fired since the
 * last render).
 *
 * Mount once, high in your root layout. Renders nothing.
 *
 * Porting: swap `usePathname` for your framework's current-path hook.
 */
export default function ScrollToTop() {
  const pathname = usePathname();
  const prevPathname = useRef(pathname);

  useEffect(() => {
    if (prevPathname.current !== pathname) {
      window.scrollTo(0, 0);
      prevPathname.current = pathname;
    }
  }, [pathname]);

  return null;
}
