'use client';

import { usePathname } from 'next/navigation';
import { getRouteBg } from './routeBackground';

/**
 * Paints the per-route background color into a CSS variable as early as possible
 * on navigation, so the page never flashes white during a transition.
 *
 * Setup (Next.js App Router):
 *  1. Mount this once, high in your root layout (inside <body>).
 *  2. Apply the variable on <html> (or <body>) so the color is live before
 *     content paints:
 *
 *       <html style={{ backgroundColor: 'var(--route-bg, #0b1c33)' }}>
 *
 * Porting to another framework: replace `usePathname` with that framework's
 * current-path hook. The rest is plain DOM.
 */
export default function RouteBackground() {
  const pathname = usePathname();
  const color = getRouteBg(pathname);
  return (
    <style
      data-route-background=""
      dangerouslySetInnerHTML={{ __html: `:root{--route-bg:${color};}` }}
    />
  );
}
