/**
 * Maps a route to the background color the page should paint BEFORE its content
 * hydrates.
 *
 * Why this exists: when you navigate, there is a brief moment where the old page
 * is gone and the new one has not painted. If the page background defaults to
 * white, you get a white flash on every navigation, which makes even a perfect
 * cross-fade look like strobing. Painting the correct per-route background onto
 * <html> immediately removes that flash and is what makes the View Transitions
 * cross-fade (see transitions.css) actually look smooth.
 *
 * Rebrand by editing DEFAULT_BG and ROUTE_BG. Keys are path prefixes; the
 * longest matching prefix wins, so put broad defaults short and specific
 * sections longer.
 */

/** The background for any route not listed below (your app's base color). */
export const DEFAULT_BG = '#0b1c33';

/**
 * Path prefix -> background color.
 * Example below gives content/reading sections a lighter background while the
 * rest of the site stays on the dark default.
 */
export const ROUTE_BG: Record<string, string> = {
  '/': DEFAULT_BG,
  '/resources': '#f7f4ec',
  '/blog': '#f7f4ec',
  '/glossary': '#f7f4ec',
};

/** Returns the background color for a pathname using longest-prefix match. */
export function getRouteBg(pathname: string | null | undefined): string {
  if (!pathname) return DEFAULT_BG;
  let bestPrefix = '';
  let color = DEFAULT_BG;
  for (const [prefix, value] of Object.entries(ROUTE_BG)) {
    const matches =
      prefix === '/' ? true : pathname === prefix || pathname.startsWith(prefix + '/');
    if (matches && prefix.length >= bestPrefix.length) {
      bestPrefix = prefix;
      color = value;
    }
  }
  return color;
}
