# Header Nav Kit: SiteHeader + sub-nav

A portable, **site-agnostic** header navigation with sub-nav. One config file
drives three surfaces:

1. **Desktop primary nav** with accessible **dropdown sub-nav** (hover, focus,
   click; closes on Escape, outside click, and route change).
2. **Contextual sub-nav rail** below the bar that shows the children of the
   section you are currently in.
3. **Mobile drawer** with an accordion for the same sub-nav.

It is the navigation counterpart to the page hierarchy in
`../01-SITE-STRUCTURE.md`: the primary links are the shell (Home, Services,
Resources, About, Contact) and the sub-nav entries are each section's children.

---

## What's in the box

```
components/
├── navConfig.ts       # ⭐ EDIT THIS to rebrand: brand, CTA, links, sub-nav, colors
├── SiteHeader.tsx     # the header: primary nav + dropdown + CTA + mobile toggle
├── HeaderSubNav.tsx   # the contextual sub-nav rail (section landing pages)
├── MobileMenu.tsx     # the mobile drawer with accordion sub-nav
└── README.md          # this file
```

---

## Requirements

| Package | Why |
| --- | --- |
| `react` (18+) | components |
| `next` (App Router) | `next/link` + `usePathname` (see "Using another framework" to swap) |
| `lucide-react` | icons (`Menu`, `X`, `ChevronDown`) |
| Tailwind CSS | layout utility classes (colors come from `navConfig.theme`, not Tailwind) |

---

## Quick start

1. Copy the `components/` folder into your project.
2. Open `navConfig.ts` and edit:
   - `brand` (name + home href)
   - `cta` (label, href, and `kind`: `link` / `tel` / `external`)
   - `items` (your primary links; give content sections a `children` array for the sub-nav)
   - `theme` (brand colors)
3. Render the header at the top of your layout:

```tsx
import SiteHeader from '@/components/SiteHeader';

export default function Layout({ children }) {
  return (
    <>
      <SiteHeader />
      <main>{children}</main>
    </>
  );
}
```

Pass your own logo node if you have one:

```tsx
<SiteHeader logo={<MyLogo />} />
```

Hide the contextual sub-nav rail (keep only dropdowns) with:

```tsx
<SiteHeader showContextualSubNav={false} />
```

---

## How sub-nav works

Any item in `navConfig.items` with a `children` array becomes a sub-nav. The
**same array** feeds all three surfaces, so you define each section once:

```ts
{
  id: 'resources',
  label: 'Resources',
  href: '/resources',
  children: [
    { id: 'blog',     label: 'Guides',   href: '/resources/blog', description: 'Long-form pillar articles.' },
    { id: 'faq',      label: 'FAQ',      href: '/faq' },
    { id: 'glossary', label: 'Glossary', href: '/glossary' },
  ],
}
```

- The desktop dropdown shows `label` + optional `description`.
- The rail and mobile accordion show `label`.
- `external: true` renders a new-tab anchor instead of a router link.

Active state is derived from the URL: exact match for `/`, prefix match for
sections, so `/resources/blog/my-post` keeps both "Resources" and "Guides" lit.

---

## Accessibility

- Primary items with a sub-nav set `aria-haspopup` and `aria-expanded`.
- Dropdowns open on hover **and** keyboard focus; Escape closes them.
- The active link carries `aria-current="page"`.
- The mobile drawer is a labelled `role="dialog" aria-modal`, locks body scroll,
  and closes on Escape, backdrop click, or route change.
- Every interactive element has a stable `data-testid`.

---

## Using another framework

The components are written for the Next.js App Router. To port them, replace two
imports in `SiteHeader.tsx`, `HeaderSubNav.tsx`, and `MobileMenu.tsx`:

| Next.js | Swap for |
| --- | --- |
| `import Link from 'next/link'` | your router's link (e.g. `react-router`'s `Link`, `wouter`'s `Link`) |
| `usePathname()` from `next/navigation` | the current path (`useLocation().pathname`, etc.) |

Everything else (dropdown state, keyboard handling, scroll lock, the
config-driven structure) is plain React and needs no changes.

---

## Re-theming

All colors live in `navConfig.theme` and are applied inline, so you re-skin
without touching the components. The Tailwind classes only handle layout,
spacing, and responsive breakpoints. If your design system already defines
header colors as CSS variables, point the `theme` values at `var(--your-token)`.
