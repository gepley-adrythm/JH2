'use client';

/**
 * SiteHeader: a portable, accessible header nav WITH sub-nav.
 *
 * Three surfaces, one config (navConfig.ts):
 *   1. Desktop primary nav. Items with `children` open an accessible dropdown
 *      sub-nav (hover, focus, and click; closes on Escape, blur, or outside
 *      click; full aria-haspopup / aria-expanded wiring).
 *   2. An optional contextual sub-nav RAIL below the bar (HeaderSubNav) that
 *      shows the children of whatever top-level section you are currently in.
 *      Toggle with `showContextualSubNav` (default true).
 *   3. A mobile drawer (MobileMenu) with an accordion for sub-nav.
 *
 * Brand-agnostic: colors come from navConfig.theme, links from navConfig.items.
 * Pass an optional `logo` node to replace the text wordmark.
 *
 * Routing note: written for the Next.js App Router (next/link + usePathname).
 * To port it, swap `Link` and `usePathname()` for your router's equivalents.
 * The dropdown / keyboard / accessibility logic is plain React and portable.
 */

import { useCallback, useEffect, useRef, useState, type ReactNode } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Menu, ChevronDown } from 'lucide-react';
import {
  siteNav,
  isNavActive,
  activeSection,
  ctaHrefProps,
  type NavItem,
} from './navConfig';
import HeaderSubNav from './HeaderSubNav';
import MobileMenu from './MobileMenu';

interface SiteHeaderProps {
  /** Optional logo node. Falls back to the brand name as a text wordmark. */
  logo?: ReactNode;
  /** Show the contextual sub-nav rail for the active section. Default true. */
  showContextualSubNav?: boolean;
}

export default function SiteHeader({ logo, showContextualSubNav = true }: SiteHeaderProps) {
  const pathname = usePathname();
  const { items, brand, cta, theme } = siteNav;
  const [openId, setOpenId] = useState<string | null>(null);
  const [mobileOpen, setMobileOpen] = useState(false);
  const closeTimer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const navRef = useRef<HTMLDivElement | null>(null);

  const openDropdown = useCallback((id: string) => {
    if (closeTimer.current) clearTimeout(closeTimer.current);
    setOpenId(id);
  }, []);

  const scheduleClose = useCallback(() => {
    if (closeTimer.current) clearTimeout(closeTimer.current);
    closeTimer.current = setTimeout(() => setOpenId(null), 140);
  }, []);

  const closeNow = useCallback(() => {
    if (closeTimer.current) clearTimeout(closeTimer.current);
    setOpenId(null);
  }, []);

  // Close dropdown on Escape and on outside click.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') closeNow();
    };
    const onClick = (e: MouseEvent) => {
      if (navRef.current && !navRef.current.contains(e.target as Node)) closeNow();
    };
    window.addEventListener('keydown', onKey);
    document.addEventListener('click', onClick);
    return () => {
      window.removeEventListener('keydown', onKey);
      document.removeEventListener('click', onClick);
    };
  }, [closeNow]);

  // Close the dropdown whenever the route changes.
  useEffect(() => {
    closeNow();
  }, [pathname, closeNow]);

  const section = showContextualSubNav ? activeSection(pathname, items) : undefined;

  const renderTopLink = (item: NavItem) => {
    const active = isNavActive(pathname, item.href);
    const hasChildren = !!item.children?.length;
    const isOpen = openId === item.id;

    if (!hasChildren) {
      return (
        <li key={item.id} role="none">
          <Link
            href={item.href}
            role="menuitem"
            data-testid={`nav-link-${item.id}`}
            className="inline-flex items-center rounded-md px-3 py-2 text-[15px] font-semibold uppercase tracking-wide transition-colors"
            style={{ color: active ? theme.barTextActive : theme.barText, letterSpacing: '0.05em' }}
            aria-current={active ? 'page' : undefined}
          >
            {item.label}
          </Link>
        </li>
      );
    }

    return (
      <li
        key={item.id}
        role="none"
        className="relative"
        onMouseEnter={() => openDropdown(item.id)}
        onMouseLeave={scheduleClose}
      >
        <Link
          href={item.href}
          role="menuitem"
          data-testid={`nav-link-${item.id}`}
          aria-haspopup="true"
          aria-expanded={isOpen}
          onFocus={() => openDropdown(item.id)}
          onClick={(e) => {
            // First tap on touch opens the menu instead of navigating.
            if (!isOpen) {
              e.preventDefault();
              openDropdown(item.id);
            }
          }}
          className="inline-flex items-center gap-1.5 rounded-md px-3 py-2 text-[15px] font-semibold uppercase tracking-wide transition-colors"
          style={{ color: active ? theme.barTextActive : theme.barText, letterSpacing: '0.05em' }}
        >
          {item.label}
          <ChevronDown
            className="h-3.5 w-3.5 transition-transform duration-200"
            style={{ transform: isOpen ? 'rotate(180deg)' : 'rotate(0deg)', opacity: 0.75 }}
          />
        </Link>

        {isOpen && (
          <div
            role="menu"
            aria-label={`${item.label} submenu`}
            data-testid={`dropdown-${item.id}`}
            className="absolute left-0 top-full z-50 mt-1 w-72 overflow-hidden rounded-lg shadow-xl"
            style={{ background: theme.panel, border: `1px solid ${theme.border}` }}
            onMouseEnter={() => openDropdown(item.id)}
            onMouseLeave={scheduleClose}
          >
            <ul className="flex flex-col py-2">
              {item.children!.map((child) => {
                const childActive = isNavActive(pathname, child.href);
                const inner = (
                  <>
                    <span className="block text-sm font-semibold" style={{ color: childActive ? theme.accent : theme.panelText }}>
                      {child.label}
                    </span>
                    {child.description && (
                      <span className="mt-0.5 block text-xs leading-snug" style={{ color: theme.panelMuted }}>
                        {child.description}
                      </span>
                    )}
                  </>
                );
                const props = {
                  role: 'menuitem',
                  'data-testid': `dropdown-${item.id}-${child.id}`,
                  className: 'block px-4 py-2.5 transition-colors',
                  'aria-current': childActive ? ('page' as const) : undefined,
                  onMouseEnter: (e: React.MouseEvent<HTMLElement>) => {
                    e.currentTarget.style.background = theme.panelHover;
                  },
                  onMouseLeave: (e: React.MouseEvent<HTMLElement>) => {
                    e.currentTarget.style.background = 'transparent';
                  },
                };
                return (
                  <li key={child.id} role="none">
                    {child.external ? (
                      <a href={child.href} target="_blank" rel="noopener noreferrer" {...props}>
                        {inner}
                      </a>
                    ) : (
                      <Link href={child.href} onClick={closeNow} {...props}>
                        {inner}
                      </Link>
                    )}
                  </li>
                );
              })}
            </ul>
          </div>
        )}
      </li>
    );
  };

  return (
    <header data-testid="site-header" className="sticky top-0 z-[9999] w-full">
      <div style={{ background: theme.bar }}>
        <nav
          ref={navRef as React.RefObject<HTMLDivElement>}
          aria-label="Main navigation"
          className="mx-auto flex max-w-[1800px] items-center justify-between gap-4 px-4 py-3 sm:px-5 md:px-6 lg:px-8"
        >
          {/* Brand */}
          <Link
            href={brand.href}
            data-testid="link-logo"
            aria-label={`${brand.name} home`}
            className="flex items-center text-xl font-bold"
            style={{ color: theme.barTextActive }}
          >
            {logo ?? brand.name}
          </Link>

          {/* Desktop primary nav */}
          <ul className="hidden items-center gap-0.5 lg:flex" role="menubar">
            {items.map(renderTopLink)}
          </ul>

          <div className="flex items-center gap-2">
            {/* CTA */}
            <Link
              {...ctaHrefProps(cta)}
              data-testid="header-cta"
              className="hidden rounded-md px-4 py-2 text-[13px] font-semibold tracking-wide transition-transform hover:-translate-y-px sm:inline-flex"
              style={{ background: theme.accent, color: theme.accentText }}
            >
              {cta.label}
            </Link>

            {/* Mobile toggle */}
            <button
              type="button"
              data-testid="button-open-mobile-menu"
              aria-label="Open menu"
              aria-expanded={mobileOpen}
              onClick={() => setMobileOpen(true)}
              className="inline-flex h-10 w-10 items-center justify-center rounded-md lg:hidden"
              style={{ color: theme.barTextActive }}
            >
              <Menu className="h-6 w-6" />
            </button>
          </div>
        </nav>
      </div>

      {/* Contextual sub-nav rail for the active section */}
      {section?.children?.length ? (
        <HeaderSubNav sections={section.children} ariaLabel={`${section.label} sections`} />
      ) : null}

      {/* Mobile drawer */}
      <MobileMenu open={mobileOpen} onClose={() => setMobileOpen(false)} />
    </header>
  );
}
