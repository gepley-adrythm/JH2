/**
 * navConfig.ts: the ONE file you edit to rebrand and re-wire the header nav.
 *
 * Everything site-specific (brand name, the call-to-action, the primary nav
 * links, and the sub-nav entries under each section) lives here. Nothing
 * brand-specific is hardcoded inside SiteHeader / HeaderSubNav / MobileMenu.
 *
 * The structure mirrors the kit's site architecture (see 01-SITE-STRUCTURE.md):
 * a small primary nav (Home, Services, Resources, About, Contact) where the
 * content-heavy sections (Services, Resources, About) carry a SUB-NAV of their
 * children. The same `children` array drives three surfaces:
 *   1. the desktop dropdown under a primary item,
 *   2. the contextual sub-nav rail below the header on section pages,
 *   3. the expandable accordion in the mobile menu.
 *
 * Edit the values below, drop the four files into any React project, and the
 * header inherits the new brand and structure without touching component code.
 */

export interface SubNavItem {
  /** Stable id used for keys and `data-testid`. */
  id: string;
  label: string;
  href: string;
  /** Optional one-line description shown in the desktop dropdown. */
  description?: string;
  /** Opens in a new tab when true. */
  external?: boolean;
}

export interface NavItem {
  id: string;
  label: string;
  href: string;
  /** When present, this item renders a sub-nav (dropdown + rail + accordion). */
  children?: SubNavItem[];
}

export interface SiteNavConfig {
  brand: {
    /** Brand display name. Rendered as the logo text if you do not pass a logo node. */
    name: string;
    href: string;
  };
  /** The single prominent action on the right of the bar. */
  cta: {
    label: string;
    href: string;
    /** `link` for an in-app route, `tel` for a phone link, `external` for a new tab. */
    kind: 'link' | 'tel' | 'external';
  };
  items: NavItem[];
  /**
   * Brand colors. Applied as CSS variables on the header root so the components
   * stay theme-driven. Override these to re-skin without editing the TSX.
   */
  theme: {
    bar: string;          // header background
    barText: string;      // primary nav text (resting)
    barTextActive: string;// primary nav text (active), logo, mobile toggle icon
    barTextMuted: string;
    accent: string;       // active state + hover underline + CTA background
    accentText: string;   // text on top of accent (CTA label)
    panel: string;        // dropdown / mobile drawer background
    panelText: string;
    panelMuted: string;
    panelHover: string;   // dropdown item hover background
    border: string;       // hairline borders
  };
}

export const siteNav: SiteNavConfig = {
  brand: {
    name: '[YOUR BRAND]',
    href: '/',
  },

  cta: {
    label: 'Get Started',
    href: '/contact',
    kind: 'link',
  },

  items: [
    { id: 'home', label: 'Home', href: '/' },

    {
      id: 'services',
      label: 'Services',
      href: '/services',
      children: [
        { id: 'category-1', label: '[Category One]', href: '/services/category-one', description: 'Short line describing this category.' },
        { id: 'category-2', label: '[Category Two]', href: '/services/category-two', description: 'Short line describing this category.' },
        { id: 'category-3', label: '[Category Three]', href: '/services/category-three', description: 'Short line describing this category.' },
        { id: 'all-services', label: 'All Services', href: '/services', description: 'Browse the full list.' },
      ],
    },

    {
      id: 'resources',
      label: 'Resources',
      href: '/resources',
      children: [
        { id: 'blog', label: 'Guides', href: '/resources/blog', description: 'Long-form pillar articles.' },
        { id: 'faq', label: 'FAQ', href: '/faq', description: 'Answers to common questions.' },
        { id: 'glossary', label: 'Glossary', href: '/glossary', description: 'Plain-language definitions.' },
      ],
    },

    {
      id: 'about',
      label: 'About',
      href: '/about',
      children: [
        { id: 'who-we-are', label: 'Who We Are', href: '/about', description: 'Our story and mission.' },
        { id: 'team', label: 'Team', href: '/team', description: 'The people behind the work.' },
        { id: 'locations', label: 'Locations', href: '/locations', description: 'Where to find us.' },
      ],
    },

    { id: 'contact', label: 'Contact', href: '/contact' },
  ],

  theme: {
    bar: '#0f3254',
    barText: 'rgba(255,255,255,0.82)',
    barTextActive: '#ffffff',
    barTextMuted: 'rgba(255,255,255,0.6)',
    accent: '#d4a853',
    accentText: '#091a33',
    panel: '#ffffff',
    panelText: '#0f3254',
    panelMuted: 'rgba(15,50,84,0.62)',
    panelHover: 'rgba(15,50,84,0.06)',
    border: 'rgba(15,50,84,0.12)',
  },
};

/** Resolve the correct href attributes for the CTA based on its `kind`. */
export function ctaHrefProps(cta: SiteNavConfig['cta']) {
  if (cta.kind === 'external') {
    return { href: cta.href, target: '_blank', rel: 'noopener noreferrer' as const };
  }
  return { href: cta.href };
}

/**
 * Is `href` the active route for `pathname`? Exact match for the home route,
 * prefix match for sections (so /services/category-one keeps "Services" active).
 */
export function isNavActive(pathname: string | null, href: string): boolean {
  if (!pathname) return false;
  if (href === '/') return pathname === '/';
  return pathname === href || pathname.startsWith(href + '/');
}

/** Find the top-level item whose section the current path belongs to. */
export function activeSection(pathname: string | null, items: NavItem[]): NavItem | undefined {
  if (!pathname) return undefined;
  return items.find((item) => {
    if (isNavActive(pathname, item.href) && item.children?.length) return true;
    return item.children?.some((c) => isNavActive(pathname, c.href));
  });
}
