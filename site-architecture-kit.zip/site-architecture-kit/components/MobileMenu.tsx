'use client';

/**
 * MobileMenu: the small-screen drawer.
 *
 * A full-height slide-in panel that mirrors the desktop nav: top-level links,
 * and an expandable accordion for any item that has `children` (its sub-nav).
 * It traps body scroll while open, closes on Escape, and closes itself on route
 * change (watch `pathname` in the parent and pass a fresh `open=false`, or rely
 * on the provided effect).
 *
 * Driven entirely by navConfig.ts. No brand strings live here.
 */

import { useEffect, useRef, useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { X, ChevronDown } from 'lucide-react';
import { siteNav, isNavActive, ctaHrefProps } from './navConfig';

interface MobileMenuProps {
  open: boolean;
  onClose: () => void;
}

export default function MobileMenu({ open, onClose }: MobileMenuProps) {
  const pathname = usePathname();
  const { items, cta, brand, theme } = siteNav;
  const [expanded, setExpanded] = useState<string | null>(null);
  const panelRef = useRef<HTMLDivElement | null>(null);
  const closeButtonRef = useRef<HTMLButtonElement | null>(null);

  // Close the drawer whenever the route changes.
  useEffect(() => {
    onClose();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pathname]);

  // While open: lock body scroll, manage focus (initial focus, focus trap,
  // restore on close), and close on Escape.
  useEffect(() => {
    if (!open) return;
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const previouslyFocused = document.activeElement as HTMLElement | null;

    const getFocusable = () =>
      Array.from(
        panelRef.current?.querySelectorAll<HTMLElement>(
          'a[href], button:not([disabled]), [tabindex]:not([tabindex="-1"])',
        ) ?? [],
      );

    // Move focus into the panel on open (close button is the safe first stop).
    (closeButtonRef.current ?? getFocusable()[0])?.focus();

    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
        return;
      }
      if (e.key !== 'Tab') return;
      const items = getFocusable();
      if (items.length === 0) return;
      const first = items[0]!;
      const last = items[items.length - 1]!;
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    };
    window.addEventListener('keydown', onKey);

    return () => {
      document.body.style.overflow = prevOverflow;
      window.removeEventListener('keydown', onKey);
      // Restore focus to whatever opened the menu (usually the hamburger).
      previouslyFocused?.focus?.();
    };
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[10000] lg:hidden" role="dialog" aria-modal="true" aria-label="Site menu">
      {/* Backdrop */}
      <button
        type="button"
        aria-label="Close menu"
        data-testid="mobile-menu-backdrop"
        onClick={onClose}
        className="absolute inset-0 bg-black/50"
      />

      {/* Panel */}
      <div
        ref={panelRef}
        className="absolute right-0 top-0 flex h-full w-[86%] max-w-sm flex-col overflow-y-auto shadow-xl"
        style={{ background: theme.panel, color: theme.panelText }}
        data-testid="mobile-menu-panel"
      >
        <div className="flex items-center justify-between px-5 py-4" style={{ borderBottom: `1px solid ${theme.border}` }}>
          <Link href={brand.href} onClick={onClose} className="text-lg font-bold" data-testid="mobile-menu-brand">
            {brand.name}
          </Link>
          <button
            ref={closeButtonRef}
            type="button"
            onClick={onClose}
            aria-label="Close menu"
            data-testid="button-close-mobile-menu"
            className="-mr-1 inline-flex h-10 w-10 items-center justify-center rounded-md"
            style={{ color: theme.panelText }}
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <nav aria-label="Mobile navigation" className="flex flex-col px-2 py-3">
          {items.map((item) => {
            const hasChildren = !!item.children?.length;
            const active = isNavActive(pathname, item.href);
            const isExpanded = expanded === item.id;

            if (!hasChildren) {
              return (
                <Link
                  key={item.id}
                  href={item.href}
                  onClick={onClose}
                  data-testid={`mobile-link-${item.id}`}
                  className="rounded-md px-3 py-3 text-base font-semibold"
                  style={{ color: active ? theme.accent : theme.panelText }}
                  aria-current={active ? 'page' : undefined}
                >
                  {item.label}
                </Link>
              );
            }

            return (
              <div key={item.id}>
                <div className="flex items-center">
                  <Link
                    href={item.href}
                    onClick={onClose}
                    data-testid={`mobile-link-${item.id}`}
                    className="flex-1 rounded-md px-3 py-3 text-base font-semibold"
                    style={{ color: active ? theme.accent : theme.panelText }}
                  >
                    {item.label}
                  </Link>
                  <button
                    type="button"
                    aria-label={`${isExpanded ? 'Collapse' : 'Expand'} ${item.label}`}
                    aria-expanded={isExpanded}
                    data-testid={`mobile-toggle-${item.id}`}
                    onClick={() => setExpanded(isExpanded ? null : item.id)}
                    className="inline-flex h-11 w-11 items-center justify-center rounded-md"
                    style={{ color: theme.panelMuted }}
                  >
                    <ChevronDown
                      className="h-5 w-5 transition-transform duration-200"
                      style={{ transform: isExpanded ? 'rotate(180deg)' : 'rotate(0deg)' }}
                    />
                  </button>
                </div>

                {isExpanded && (
                  <ul className="mb-1 ml-3 flex flex-col gap-0.5 border-l pl-3" style={{ borderColor: theme.border }}>
                    {item.children!.map((child) => {
                      const childActive = isNavActive(pathname, child.href);
                      const childProps = {
                        'data-testid': `mobile-sublink-${child.id}`,
                        className: 'block rounded-md px-3 py-2.5 text-[15px]',
                        style: { color: childActive ? theme.accent : theme.panelMuted },
                      };
                      return (
                        <li key={child.id}>
                          {child.external ? (
                            <a href={child.href} target="_blank" rel="noopener noreferrer" {...childProps}>
                              {child.label}
                            </a>
                          ) : (
                            <Link
                              href={child.href}
                              onClick={onClose}
                              aria-current={childActive ? 'page' : undefined}
                              {...childProps}
                            >
                              {child.label}
                            </Link>
                          )}
                        </li>
                      );
                    })}
                  </ul>
                )}
              </div>
            );
          })}
        </nav>

        <div className="mt-auto px-5 py-4" style={{ borderTop: `1px solid ${theme.border}` }}>
          <Link
            {...ctaHrefProps(cta)}
            onClick={onClose}
            data-testid="mobile-cta"
            className="flex w-full items-center justify-center rounded-md px-4 py-3 text-sm font-semibold"
            style={{ background: theme.accent, color: theme.accentText }}
          >
            {cta.label}
          </Link>
        </div>
      </div>
    </div>
  );
}
