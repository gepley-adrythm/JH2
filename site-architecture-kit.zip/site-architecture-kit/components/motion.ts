import { useEffect, useState } from 'react';

/**
 * Shared motion tokens for page and content transitions.
 *
 * The numbers here (easing curve, durations) are framework-agnostic and port to
 * any animation library or to plain CSS. The object props are shaped for
 * Framer Motion (`m.div` / `motion.div`), but you can read the values out and
 * apply them anywhere.
 *
 * The whole point of centralizing these is consistency: every transition on the
 * site uses the SAME easing and a small set of durations, so the motion feels
 * like one designed system instead of a pile of one-off animations.
 */

/**
 * Expo-style ease-out. This single curve is used across the entire site. If you
 * change one thing about the motion, change it here.
 */
export const EASE_OUT_EXPO: [number, number, number, number] = [0.22, 1, 0.36, 1];

/** Transition used for scroll-into-view section reveals. */
export const SECTION_TRANSITION = {
  duration: 0.5,
  ease: EASE_OUT_EXPO,
};

/** Reusable "animate once when it enters the viewport" config. */
export const VIEWPORT_ONCE = { once: true } as const;

/**
 * Scroll-into-view entrance for any section or card.
 * Use with Framer Motion's `whileInView`:
 *   <m.section {...FADE_IN_UP_PROPS}>...</m.section>
 */
export const FADE_IN_UP_PROPS = {
  initial: { opacity: 0, y: 20 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, margin: '-40px' as const },
  transition: { duration: 0.5, ease: EASE_OUT_EXPO },
} as const;

/**
 * In-page transition for tab or sub-page switches. Use inside
 * `<AnimatePresence mode="wait">`, keyed on the active tab id, so the outgoing
 * panel fades up and out while the incoming one fades in:
 *
 *   <AnimatePresence mode="wait">
 *     <m.div key={activeTab} {...TAB_SWITCH_PROPS}>{panel}</m.div>
 *   </AnimatePresence>
 */
export const TAB_SWITCH_PROPS = {
  initial: { opacity: 0, y: 12 },
  animate: { opacity: 1, y: 0 },
  exit: { opacity: 0, y: -12 },
  transition: { duration: 0.3, ease: EASE_OUT_EXPO },
} as const;

/**
 * One-time snapshot of the visitor's reduce-motion preference, read at module
 * load. Cheap and fine for a quick guard, but note two limits: it is `false`
 * during server rendering (so do not branch render output on it, or you will get
 * a hydration mismatch), and it does NOT update if the visitor changes the
 * setting while the page is open. For anything render-affecting or long-lived,
 * use the `useReducedMotion` hook below instead.
 */
export const PREFERS_REDUCED_MOTION =
  typeof window !== 'undefined' &&
  window.matchMedia('(prefers-reduced-motion: reduce)').matches;

/**
 * Reactive reduce-motion preference for React components. Returns `false` on the
 * server and on the first client render (matching SSR, so no hydration
 * mismatch), then updates to the real value and re-renders if the visitor
 * toggles the OS setting. Use this in a client component, not the constant
 * above, whenever the preference affects what you render:
 *
 *   const reduceMotion = useReducedMotion();
 *   <m.div {...(reduceMotion ? {} : TAB_SWITCH_PROPS)} />
 */
export function useReducedMotion(): boolean {
  const [reduce, setReduce] = useState(false);
  useEffect(() => {
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    setReduce(mq.matches);
    const onChange = (e: MediaQueryListEvent) => setReduce(e.matches);
    mq.addEventListener('change', onChange);
    return () => mq.removeEventListener('change', onChange);
  }, []);
  return reduce;
}
