# Site Structure

The page hierarchy for a content-driven marketing site. This is the skeleton every other part of the kit hangs off of. Replace bracketed placeholders with your own.

A good structure does three jobs at once: it tells **visitors** what you offer and how to act, it tells **search engines** how your topics relate, and it gives **content** a permanent home to link into. Get the skeleton right first; the content modules in `03-CORE-CONTENT-MODULES.md` then slot into it.

---

## The five top-level sections

Almost every effective marketing site reduces to five top-level areas. Start here, add only what you need.

```
/                      Home
/services              What you offer (the money pages)
/resources             What you know (the content engine: blog, faq, glossary)
/about                 Who you are (trust + credibility)
/contact               How to act (conversion)
```

Everything else is a child of one of these, or a utility page (legal, sitemap, and so on).

---

## 1. Home (`/`)

The front door. Its only job is to orient a first-time visitor in seconds and route them to the right next step.

A home page should answer, above the fold:
- **What is this?** One clear value statement.
- **Who is it for?** The audience or problem you solve.
- **What do I do next?** One primary call to action (book, buy, call, get a quote), one secondary (browse services or resources).

Below the fold, summarize the five sections: a strip of top services, a few featured resources, proof (reviews, logos, credentials), and a closing call to action. Home links **out** to everything and is linked **to** by your logo on every page. It should not try to rank for deep topics. That is what Services and Resources are for.

## 2. Services (`/services`)

Your "money pages," the things you actually sell or deliver. This is usually a **two-level** structure:

```
/services                          Overview: all categories + all services
/services/[category]               Category landing (e.g. /services/[category-slug])
/services/[category]/[service]     Individual service detail page
```

- **Overview** groups services into a small number of **categories** (aim for 2 to 6). Each category gets a short intro and links to its services.
- **Category pages** explain the category, list its services, and answer category-level questions.
- **Service detail pages** are the conversion targets. Each one covers a single offering: what it is, who it is for, how it works, what is included, pricing context if you share it, and a call to action. Every service page should link to **related resources** (the blog pillar and FAQs about that service) and carry the right structured data (see `02-SEO-ARCHITECTURE.md`).

Keep service data in a **single source of truth** (one data file or CMS collection) so categories, navigation, sitemaps, and internal links all read from the same place. Do not hardcode the same service list in five components.

## 3. Resources (`/resources`)

The content engine and the heart of your SEO. This is where Blog, FAQ, and Glossary live. Treat `/resources` as a hub with tabs or sub-sections:

```
/resources                         Hub: featured + tabs (Blog | FAQ | Glossary)
/resources/blog/[slug]             Long-form pillar guides   (see core modules)
/faq  or  /resources/faq/[slug]    Focused Q&A               (see core modules)
/glossary/[slug]                   Term definitions          (see core modules)
```

URL placement is flexible. Blog, FAQ, and Glossary can live under `/resources/...` or at the root (`/faq`, `/glossary`). What matters is that the hub links to all three and they link to each other. The full design of these three modules is in `03-CORE-CONTENT-MODULES.md`.

## 4. About (`/about`)

Trust and credibility. People buy from sites they believe. Cover the story, the mission, the people (a `/about/team` or `/team` page with real names and credentials), and any proof that you are legitimate, such as years in business, certifications, results, and locations. About pages rarely rank, but they are read by people deciding whether to convert, so they directly affect conversion rate.

## 5. Contact (`/contact`)

The conversion surface. Make it effortless to act: a form, a phone number, an email, hours, and location if relevant. Keep contact details in **one config file** and import them everywhere (footer, contact page, schema) so there is never a stale phone number on the site. If you have a multi-step or specialized form, this is where it lives. (For a ready-made, brand-agnostic set of conversion form components, see the companion **form styles kit**.)

---

## Supporting and utility pages

Beyond the five sections, most sites need a small set of supporting pages:

- **Legal**: `/privacy`, `/terms`, and any industry-required disclosures. Link these in the footer. Never hardcode contact info in them; import from your central config.
- **Conversion landing pages**: standalone pages for paid traffic (ads, email). Keep these in their own route group (e.g. `/lp/[slug]`) with a stripped-down layout: no global nav, a single focused offer, one call to action. They are built for conversion, not for organic ranking.
- **Locations** (if you serve specific places): `/locations/[city]` pages for local SEO. Each targets one place with genuinely local content, not a templated copy with the city name swapped.
- **Tools / interactive features**: self-service calculators, checklists, or visualizers under `/tools`. These earn links and engagement (see `04-BUILDING-NEW-MODULES.md`).
- **Technical SEO files**: `sitemap.xml`, `robots.txt`, and (increasingly) an `llms.txt` for AI crawlers. These are covered in `02-SEO-ARCHITECTURE.md`.

---

## Navigation

- **Header**: the five top-level sections plus one prominent call-to-action button. Do not cram every page into the top nav; link to the five hubs and let each hub branch out.
- **Footer**: the fuller map, with services by category, resource links, about/team, contact, and legal. The footer is both a usability aid and an internal-linking surface that spreads link equity to deep pages.
- **Breadcrumbs**: on every nested page (`Home > Services > Category > Service`). They help users and emit `BreadcrumbList` structured data (see `02-SEO-ARCHITECTURE.md`).

---

## URL conventions

Consistent URLs are an SEO asset. Apply these rules everywhere:

- **Lowercase, hyphen-separated slugs.** `/services/estate-planning`, never `/Services/Estate_Planning`.
- **Short and descriptive.** The slug should read like the topic. Drop filler words.
- **Stable.** A published URL is a promise. If you must change one, 301-redirect the old URL to the new one. Never leave it as a 404.
- **Logical nesting that mirrors the hierarchy.** A service detail page lives under its category; a blog post lives under the blog. The path should tell you where you are.
- **One canonical URL per page.** Avoid serving the same content at multiple URLs (with/without trailing slash, with tracking params). Pick one canonical form and redirect or canonicalize the rest.

---

## Build order for the shell

Before any content goes in, stand up the skeleton. The **shell** is the four conversion-critical pages:

1. **Home** with a clear value proposition and primary call to action.
2. **Services** (single source of truth for offerings) so you have money pages to send traffic to.
3. **Contact** so visitors can convert from day one.
4. **About / Team** for credibility.

Then scaffold one more page as the bridge into the content phase:

5. **Resources hub** as an empty container, ready for the content modules to fill.

This is the same shell referenced throughout the kit (Home, Services, About, Contact), with the Resources hub scaffolded as the empty vessel the content phase fills next. With the shell live, move to `03-CORE-CONTENT-MODULES.md` and start filling Resources. The SEO model in `02-SEO-ARCHITECTURE.md` explains how all of these pages link together into something that ranks.
