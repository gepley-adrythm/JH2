# SEO Architecture

The engine that turns a pile of pages into a site that ranks. This file covers the **pillar/cluster model**, **internal linking**, **structured data (JSON-LD)**, **metadata rules**, and the **technical SEO surfaces**. It is site-agnostic. Replace bracketed placeholders with your own.

Pair this with the two companion guides: `SEO-FAQ-QUALITY-STANDARDS.md` (how to write a page well) and `SEO-FAQ-IDEA-SOURCING.md` (how to find topics). This file is about how pages relate to **each other**.

---

## 1. The pillar / cluster model

Search engines reward **topical authority**, meaning you cover a subject so thoroughly and so interlinked that you become the obvious best answer. You build authority with a hub-and-spoke pattern:

```
            ┌──────────────────────────┐
            │   PILLAR  (blog guide)    │   broad, deep, 1,500-3,000 words
            │   "Everything about X"    │   targets the head term
            └────────────┬─────────────┘
        links down       │       links up
   ┌──────────────┬──────┴──────┬──────────────┐
   ▼              ▼             ▼               ▼
 FAQ            FAQ          FAQ            GLOSSARY
"How much      "Do I        "X vs Y"       "X" (term
 does X cost?"  need X?"                     definition)
   long-tail, one intent each            shared vocabulary
```

- A **pillar** is a comprehensive guide to a major topic (built as a long-form Blog post). It targets the broad "head" term and links down to every related cluster page.
- A **cluster** is the set of focused pages around that pillar: the FAQs answering specific questions, and the Glossary terms defining the vocabulary. Each cluster page links **back up** to its pillar.
- The links flowing both directions are what tell search engines "this site owns this topic."

**Practical rule:** every cluster page names its pillar and links to it; every pillar lists and links to its cluster pages. If a cluster has no pillar yet, the page should degrade gracefully (just omit the "start with the full guide" link) until the pillar ships.

The format decision (is this idea a pillar, an FAQ, or a glossary term?) is made with the decision tree in `SEO-FAQ-QUALITY-STANDARDS.md`. Always pick the format **before** writing.

---

## 2. Internal linking

Internal links are the single most under-used SEO lever. They pass ranking signals, define topical relationships, and guide users deeper. Make linking **structural**, not manual-and-forgotten:

- **Relate content by stable IDs, not pasted URLs.** Give each piece of content an ID, and let pages reference related content by ID (`relatedFaqIds`, `relatedServiceIds`, `relatedTerms`). The system resolves IDs to current URLs at render time, so links never rot when a slug changes.
- **Every money page links to its supporting content.** A service page links to the pillar guide and the FAQs about that service. This sends engaged readers toward conversion and engaged link equity toward the money page.
- **Every content page links to a next step.** A blog pillar links to the relevant service and to a call to action. A glossary term links to the FAQ or pillar that explains it in depth.
- **Cross-link siblings within a cluster.** Related FAQs link to each other. Related terms link to each other.
- **Use the footer and breadcrumbs as linking surfaces.** The footer spreads equity to deep pages; breadcrumbs reinforce hierarchy.

A healthy site has **no orphan pages** (pages nothing links to) and **no dead ends** (pages that link nowhere).

---

## 3. Structured data (JSON-LD)

Structured data is machine-readable context that powers rich results and, increasingly, AI answer engines. Emit JSON-LD via a `<script type="application/ld+json">` block on each page. Map page types to schema types:

| Page type | Primary schema.org type |
| --- | --- |
| Site-wide (every page) | `Organization` (name, logo, contact, social profiles) |
| Business with a physical/service area | `LocalBusiness` or the specific subtype for your industry |
| Home / brand search | `WebSite` (optionally with `SearchAction`) |
| Service detail page | `Service` (or `Product` / `Offer` for products) |
| Blog pillar / article | `Article` or `BlogPosting` |
| FAQ page (editorial, site-authored) | `FAQPage` (one or many Q&As you wrote yourself) |
| User-submitted Q&A (forum-style) | `QAPage` (one question with visitor-contributed answers) |
| Glossary term | `DefinedTerm` (and `DefinedTermSet` for the whole glossary) |
| Any nested page | `BreadcrumbList` |
| Events (optional module, see `04-BUILDING-NEW-MODULES.md`) | `Event` |
| Job postings (optional module) | `JobPosting` |
| Reviews / ratings (optional) | `Review` / `AggregateRating` |

**The cardinal rule: never emit the same `@type` twice on one page.** If a layout already injects `Organization`, a page must not inject a second `Organization`. Decide once where each global type is emitted (usually the root layout) and let page-level blocks add only their page-specific type. Duplicate types confuse parsers and can suppress rich results.

**Keep structured data truthful.** It must faithfully represent what is on the page. The answer, price, rating, or event detail in your markup has to match the visible content a reader can actually find. Do not inject claims or answers that exist only in the markup. Fake or hidden-only markup risks manual penalties.

---

## 4. Metadata rules

Every page needs unique, deliberate metadata. Centralize the rules so they are consistent:

- **Title tag**: unique per page, descriptive, front-loaded with the topic. A common pattern is `Primary Topic - Qualifier | [YOUR BRAND]`. Define the ` | [YOUR BRAND]` suffix **once** as a template and do not repeat it inside individual titles, or you get `... | [YOUR BRAND] | [YOUR BRAND]`. Aim for roughly 50 to 60 characters.
- **Meta description**: unique per page, 150 to 160 characters, written to earn the click (it is ad copy, not a summary). It does not directly affect ranking but heavily affects click-through.
- **Canonical URL**: every page declares its canonical self to prevent duplicate-content dilution from query params or trailing-slash variants.
- **Open Graph + Twitter cards**: title, description, and a share image so links look intentional when shared. Generating a branded share image per content type is a high-leverage polish step.
- **One H1 per page**: the visible headline. Subsequent headings are H2/H3 in a logical outline. If a design hides the headline visually, keep a real H1 in the markup (e.g. screen-reader-only) so the page still has a semantic top heading.
- **Centralize overrides**: keep a single map of per-page SEO titles/descriptions so non-developers can tune metadata without touching component code.

---

## 5. Technical SEO surfaces

These site-wide files and behaviors make the whole thing crawlable and fast:

- **XML sitemap** (`/sitemap.xml`): list every indexable URL, generated from your single sources of truth (services data, content seeds) so it is never stale. Submit it in search console tools.
- **`robots.txt`**: allow crawling of indexable content, disallow admin/utility/duplicate routes, and point to the sitemap.
- **`llms.txt`** (emerging standard): a plain-text map of your most important content for AI crawlers and answer engines. Increasingly worth maintaining alongside the sitemap.
- **Redirects**: 301-redirect any changed or retired URL to its closest live equivalent. Maintain a redirect map; never ship a link to a 404.
- **Performance / Core Web Vitals**: fast loads, stable layout (no content jumping), responsive images served at the right size. Speed is both a ranking factor and a conversion factor.
- **Mobile-first**: the mobile rendering is what gets indexed. Design and test mobile first.
- **Server-rendered content**: ensure crawlers receive the real content in the initial HTML (SSR or static generation), not a blank shell that needs JavaScript to populate.

---

## How this connects to the rest of the kit

- The **page types** that carry this schema and metadata are defined in `01-SITE-STRUCTURE.md`.
- The **content** that fills the pillar/cluster model is built per `03-CORE-CONTENT-MODULES.md`.
- When you add a **new module** (`04-BUILDING-NEW-MODULES.md`), it must bring its own schema type, its own metadata, its sitemap entries, and its internal links into the existing clusters. Otherwise it fragments the authority you have built.
