# Site Architecture Kit

A site-agnostic blueprint for building a content-driven marketing website that ranks in search, earns AI citations, and converts visitors into leads or customers.

This kit documents the **core architecture** that works for any business: the page structure (Home, Services, Resources, About, Contact), the SEO model that ties it together, and the three content modules every site should build first: **Blog (pillars)**, **FAQ**, and **Glossary**. It then explains how to layer business-specific modules on top of that core without breaking SEO. It also covers **framework and rendering choices**, and ships a ready-to-use, brand-agnostic **header nav component with sub-nav**.

Everything here is generalized. Replace bracketed placeholders like `[YOUR BRAND]`, `[YOUR REGION]`, `[YOUR INDUSTRY]`, or `[YOUR TOPIC]` with your own. Nothing in this kit assumes a particular industry, framework, or CMS. The patterns apply whether you build in Next.js, Astro, WordPress, or anything else.

---

## Read in this order

1. **[01-SITE-STRUCTURE.md](./01-SITE-STRUCTURE.md)**: the page hierarchy. What pages exist, what each one is for, how they nest, and the URL conventions that hold it together.
2. **[02-SEO-ARCHITECTURE.md](./02-SEO-ARCHITECTURE.md)**: the SEO engine. The pillar/cluster model, internal linking, structured data (JSON-LD), metadata rules, and the technical SEO surfaces (sitemaps, robots, redirects).
3. **[03-CORE-CONTENT-MODULES.md](./03-CORE-CONTENT-MODULES.md)**: the content engine. How Blog, FAQ, and Glossary are built, what each format is for, and how they cross-link into one compounding system.
4. **[04-BUILDING-NEW-MODULES.md](./04-BUILDING-NEW-MODULES.md)**: the growth playbook. When and how to add business-specific modules (case studies, tools, directories, location pages, and so on) after the core is in place.
5. **[05-FRAMEWORKS.md](./05-FRAMEWORKS.md)**: the build foundation. How to choose a framework and, more importantly, the rendering model (SSG / ISR / SSR / CSR) for each page so every indexable page ships real HTML.
6. **[06-BACKEND-AND-STACK.md](./06-BACKEND-AND-STACK.md)**: what to stand up. The reference stack, the typed data model, the seed-to-database content pipeline, optional semantic search, media/CDN handling, and secrets, in setup order.
7. **[07-FRAMEWORK-PATTERNS.md](./07-FRAMEWORK-PATTERNS.md)**: how to build it correctly. The rendering and SEO patterns (server-rendered H1, avoiding accidental client-side rendering, payload discipline) and the version gotchas that quietly break them.
8. **[08-PAGE-TRANSITIONS.md](./08-PAGE-TRANSITIONS.md)**: how to make navigation feel smooth. The layered transition system (no white flash, native cross-route fade, scroll reset, staggered content entrance, animated tab switches), shipped as real brand-agnostic code in `components/`.

## Header nav component

The kit ships a working, brand-agnostic navigation, not just docs. It is a header with primary nav, an accessible **dropdown sub-nav**, a contextual sub-nav rail for the active section, and a mobile drawer, all driven by one config file.

- **[components/](./components/)**: `SiteHeader.tsx`, `HeaderSubNav.tsx`, `MobileMenu.tsx`, and `navConfig.ts`. Start with **[components/README.md](./components/README.md)** for setup, theming, and how to port it off Next.js.

## Page transition system

The kit also ships the real, brand-agnostic code for smooth navigation, documented in `08-PAGE-TRANSITIONS.md`.

- **[components/](./components/)**: `RouteBackground.tsx` and `routeBackground.ts` (no white flash), `ScrollToTop.tsx` (scroll reset), `transitions.css` (native cross-route fade, staggered hero entrance, reduced-motion guards), and `motion.ts` (shared easing and motion tokens).

## Included companion guides

These two files were delivered separately and are bundled here because the content modules depend on them. They cover **FAQ** specifically but the principles (one intent per page, format-first thinking, harvesting real questions) apply to every content module in this kit.

- **[SEO-FAQ-QUALITY-STANDARDS.md](./SEO-FAQ-QUALITY-STANDARDS.md)**: *how to write content well.* The quality bar: one intent per page, the format decision tree, anti-cannibalization rules.
- **[SEO-FAQ-IDEA-SOURCING.md](./SEO-FAQ-IDEA-SOURCING.md)**: *what to write.* How to find real topics worth writing without paid keyword tools.

---

## The one-paragraph version

Build the **shell** first (Home, Services, About, Contact) so visitors can find what you sell and how to reach you. Then build the **content core** in a deliberate order: **Glossary** establishes your vocabulary, **Blog pillars** own your biggest topics in depth, and **FAQ clusters** capture the long tail of real questions. These three interlink: pillars link down to FAQs and glossary terms, FAQs link up to their pillar, and glossary terms link out to both. That web of internal links is what makes the whole site rank. Only **after** the core is healthy do you add business-specific modules, and each new module must plug into the same linking and schema patterns so it strengthens the core instead of fragmenting it.

## How to use this kit with an AI agent

Point your agent at this folder and tell it which file applies to the task:

- Planning the whole site, start with `01-SITE-STRUCTURE.md`.
- Writing or reviewing a blog post, FAQ, or glossary term, use `03-CORE-CONTENT-MODULES.md` plus the two companion guides.
- Adding a new section the core does not cover, use `04-BUILDING-NEW-MODULES.md`.
- Any SEO or schema question, use `02-SEO-ARCHITECTURE.md`.
- Choosing a framework or per-page rendering model, use `05-FRAMEWORKS.md`.
- Standing up the stack, data layer, content pipeline, or image handling, use `06-BACKEND-AND-STACK.md`.
- Writing components without breaking server rendering or SEO, use `07-FRAMEWORK-PATTERNS.md`.
- Making navigation feel smooth (transitions, no white flash, content entrance), use `08-PAGE-TRANSITIONS.md`.
