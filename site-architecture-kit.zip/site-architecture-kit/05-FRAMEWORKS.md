# Frameworks and Rendering

This kit is framework-agnostic by design. The site structure, SEO model, and
content modules in the earlier docs work on any modern stack. But the stack you
pick decides how easily you can deliver them, because the single most important
property of a content-and-SEO site is **how each page is rendered and when**.

Read this before you commit to a framework. The wrong rendering model is the
most expensive mistake to undo later.

---

## 1. Why rendering strategy is the real decision

Search engines and answer engines rank what they can fetch as HTML. If your
pages assemble themselves in the browser after JavaScript runs, you are betting
your rankings on a crawler choosing to execute that JavaScript, wait for it, and
index the result. Sometimes it does. Often it does so late, partially, or not at
all. For a site whose entire value is content discovery, that is a bet you do
not need to make.

So the question that drives framework choice is not "React or Vue." It is: **can
this page ship complete, meaningful HTML on the first response?** Everything
below is about answering yes.

---

## 2. The four rendering models

| Model | What it means | HTML on first response? | Best for |
| --- | --- | --- | --- |
| **SSG** (Static Site Generation) | Pages are pre-built at deploy time into static HTML | Yes, fully | Content that changes rarely: glossary, pillar guides, service pages |
| **ISR** (Incremental Static Regeneration) | Static pages that re-build in the background on a schedule or on-demand | Yes, fully | Large content sets that update occasionally: FAQ, blog, location pages |
| **SSR** (Server-Side Rendering) | HTML is rendered per request on the server | Yes, fully | Personalized or always-fresh pages: search results, dashboards, anything per-user |
| **CSR** (Client-Side Rendering) | The server sends a near-empty shell; the browser builds the page | No | App-like surfaces behind a login where SEO does not matter |

The first three all ship real HTML. **CSR does not, and that is why a
content-driven public site should never render its indexable pages with CSR.**

### How to choose per page

- **Does the page need to rank or be cited?** It must be SSG, ISR, or SSR. Never
  CSR.
- **Does its content change rarely?** Prefer **SSG**. It is the fastest and the
  cheapest to serve, and it cannot break at request time.
- **Does it change occasionally and is there a lot of it?** Use **ISR** so you
  get static performance without rebuilding the whole site for one edit.
- **Must it be fresh on every view or vary per user?** Use **SSR**.
- **Is it private app UI behind auth?** CSR is fine. SEO is irrelevant there.

Most pages in this kit's architecture are SSG or ISR. Reserve SSR for the few
surfaces that genuinely cannot be cached.

---

## 3. What a framework must give you

Screen any candidate against this checklist. If it cannot do the top group, it
is the wrong tool for a content-and-SEO site.

**Non-negotiable**
- Server rendering or static generation for every public page (SSG / ISR / SSR).
- File-based or otherwise predictable routing that maps cleanly to your URL plan
  (see `01-SITE-STRUCTURE.md`).
- Per-page metadata: unique `<title>`, meta description, canonical, Open Graph
  (see `02-SEO-ARCHITECTURE.md`).
- A way to emit JSON-LD structured data per page without duplicating types.
- Programmatic sitemap and robots generation.

**Strongly preferred**
- Incremental / on-demand revalidation so one content edit does not force a full
  rebuild.
- Image optimization (responsive sizes, modern formats) at the framework or CDN
  layer.
- Built-in redirect handling for when URLs change.
- A clean data layer for reading content from files, a CMS, or a database at
  build or request time.

**Nice to have**
- Partial hydration / islands so interactive widgets do not ship a full app's
  worth of JavaScript on otherwise static pages.
- Edge rendering for low-latency SSR close to the visitor.

---

## 4. The options, honestly

There is no single right answer. Pick by how content-heavy versus app-heavy your
site is.

- **Next.js (React).** The default for a content site that also has interactive
  product surfaces. Gives you SSG, ISR, and SSR per route, a metadata API,
  built-in image optimization, and on-demand revalidation. Heaviest of the
  options, but the most flexible when the site grows into app-like features.
- **Astro.** Purpose-built for content sites. Ships zero JavaScript by default
  and hydrates only the interactive "islands" you mark. Excellent Core Web
  Vitals out of the box. Choose it when the site is mostly reading surfaces with
  a few interactive widgets, and you do not need a full app framework.
- **SvelteKit / Nuxt (Vue) / Remix (React).** All deliver SSR/SSG with strong
  routing and data loading. Good choices if your team already knows Svelte, Vue,
  or prefers Remix's data conventions. Evaluate them against the section 3
  checklist exactly as you would Next.js.
- **A traditional CMS (e.g. WordPress) or static-site generator (Hugo, Eleventy).**
  Still completely valid for a content-first site with little custom interactivity.
  They render HTML on the server by default, which is the property that matters.
  The tradeoff is less freedom when you later want rich, app-like components.
- **A plain SPA (Create React App, Vite SPA with client-only routing).** Avoid
  for the public, indexable site. It is CSR by default, which fails the one test
  that matters here. It is the right tool only for the authenticated app behind
  your marketing site.

---

## 5. How this maps to the rest of the kit

- The **URL plan** in `01-SITE-STRUCTURE.md` should translate directly into your
  framework's routing. If a clean route is awkward to express, that is a signal
  about the framework, not your URLs.
- The **metadata and JSON-LD rules** in `02-SEO-ARCHITECTURE.md` assume the
  framework can set per-page head tags and inject structured data server-side.
  Confirm that before you build content.
- The **content modules** in `03-CORE-CONTENT-MODULES.md` are mostly SSG or ISR.
  When you stand up a new module per `04-BUILDING-NEW-MODULES.md`, decide its
  rendering model up front using the per-page guide in section 2 above.
- The **header nav components** in `components/` are written for the Next.js App
  Router but port to any framework by swapping the link and current-path
  imports. See `components/README.md`.

The takeaway: choose the rendering model per page first, pick the framework that
makes those models easy second, and never let an indexable page fall back to
client-only rendering.

Once you have chosen, `06-BACKEND-AND-STACK.md` covers what to stand up (stack,
data layer, content pipeline, media, secrets) and `07-FRAMEWORK-PATTERNS.md`
covers the patterns and gotchas that keep every page shipping real HTML.
