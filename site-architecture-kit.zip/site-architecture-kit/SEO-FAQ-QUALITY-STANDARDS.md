# SEO FAQ Content Quality Standards

A universal, copy-paste-ready standard for writing and reviewing FAQ content that ranks in search, earns AI citations, and avoids the three killers of FAQ SEO: **duplicate intent**, **thin content**, and **keyword cannibalization**.

Use this on any website. Replace bracketed placeholders like `[YOUR REGION]`, `[YOUR TOPIC]`, or `[YOUR BRAND]` with your own.

---

## 1. The Core Rule: One Intent, One Page

Every FAQ page must target a **single, unique user intent**. If two questions answer the same underlying need with different wording, they belong on **one page**, not two.

### The Satisfaction Test

The deciding question:

> **Would a reasonable person searching for Question A feel satisfied landing on Question B's page?**

- **Yes** → same intent. Merge or enhance. Do not create a second page.
- **They'd bounce and keep searching** → different intent. A new page is justified.

### Same intent (merge these)

- "What is X?" vs. "How does X work?" (same core question, different phrasing)
- "Do I need X?" vs. "Should I get X?" vs. "Is it smart to have X?" (identical intent)

### Different intent (separate pages are correct)

- "What is X?" (concept explanation)
- "X vs. Y" (a specific distinction for someone who already understands X)
- "How much does X cost?" (pricing/budgeting question)

### Gray area (get a human decision)

When overlap is heavy but not identical, do not guess. Flag it and let a human decide:

- "What happens if I don't do X?" vs. "What are the risks of skipping X?"
- "Do I need X if I have Y?" vs. "What is the difference between X and Y?"

---

## 2. Pick the Right Format First

Before writing a single word, confirm an FAQ is actually the right container. FAQ content competes with (and should complement) definitions (glossary) and long-form guides (blog).

```
New content idea
       |
       v
Is it a definition / concept?  --YES-->  GLOSSARY (150-300 words)
       |
       NO
       |
       v
Can it be fully answered in one
focused question?  --YES-->  FAQ (500-1,500 words)
       |
       NO
       |
       v
Does it need 1,500+ words, a step-by-step
process, or a multi-concept comparison?
       |
   YES--> BLOG / GUIDE (1,500-3,000 words)
   NO --> FAQ with a deeper answer
```

**Write an FAQ when:**

- The topic answers a single, focused question
- It can be covered thoroughly in 500-1,500 words
- It targets a question-based search query ("can I," "do I need," "what happens if," "how long does")
- It fits naturally as `QAPage` structured data
- Someone searching would be satisfied with a direct, focused answer

**Do NOT write an FAQ when** the topic needs 1,500+ words, a multi-phase process, or an in-depth comparison. That is a blog/guide. A definition under 300 words is a glossary entry.

### Complement, never compete

When a guide and an FAQ cover related ground, they must reinforce each other:

| Long-form guide covers | FAQ covers |
|---|---|
| Comprehensive process guide | One focused question pulled from the guide |
| Deep comparison | One specific distinction |
| Broad topic overview | One specific scenario from the topic |

The FAQ links to the guide for deeper reading. The guide does not repeat the FAQ's focused answer.

---

## 3. The Pre-Write Checklist (run before adding any FAQ)

1. **Check the intent registry.** Maintain a single source of truth that maps every existing FAQ to its core intent, awareness stage, and unique angle. Read it before proposing anything new.
2. **Run a duplicate check.** Search existing FAQs for overlapping keywords and intent. If matches surface, classify the overlap (below).
3. **Classify the overlap:**
   - **A. Clear duplicate** (same intent, different wording): do NOT create a page. Enhance the existing one.
   - **B. Distinct subtopic** (related but different intent): create the page, and document why it is distinct.
   - **C. Gray area:** ask a human to make the call. Do not decide unilaterally.
4. **Log the decision** in the intent registry: new entry, enhancement note, or a line in a "Rejected Proposals" section explaining why.
5. **Verify depth** against the quality thresholds in Section 6.

---

## 4. Keyword Ownership

Every primary keyword cluster is owned by **exactly one** piece of content (one FAQ, one guide, or one glossary entry).

- If two pieces target the same cluster, one is canonical and the other links to it instead of competing.
- Maintain a keyword ownership map alongside the intent registry. Check it before claiming a new cluster.

---

## 5. Question Titles (the single most important line)

The question title drives how search engines index the page, how AI assistants cite it, and whether anyone clicks. Get it right.

1. **Use natural question format.** Start with What, How, Do I, Can I, When, Should I, or Why. Match how real people type and ask AI. Avoid listicle hooks ("7 Things You Need to Know About X").
2. **Front-load the topic.** Put the key terms first. AI systems weight the opening words heavily.
   - Good: "Do beneficiary designations override my will?"
   - Weaker: "What is the relationship between my will and the designations on my accounts?"
3. **Add a geo qualifier when the answer is location-specific.** Include `[YOUR REGION]` for region-specific law, process, or thresholds. Skip it for universal topics.
4. **The title must cover every major section of the answer.** If the body covers five subtopics, the title must be broad enough to encompass them without going vague. A title that only describes one section signals thin content.
5. **Keep it under ~70 characters** so it does not truncate in search results and works as a clean AI citation anchor.
6. **Use "vs" framing for comparisons** so the comparison intent is obvious.
7. **Avoid advice-column hooks.** Write the question someone would actually search.
   - Good: "Should I add my child to my house title to avoid probate?"
   - Avoid: "Why Adding Your Child to Your Deed Is a Nightmare"

When you expand an existing FAQ with new sections, re-check that the title still covers the wider scope. Update it if the body has outgrown it, and confirm the slug still makes sense.

---

## 6. Content Depth & Length

**Minimum quality bar for every FAQ answer:**

- At least **500 words**. No thin content.
- Genuinely useful, specific information, not generic filler.
- References region-specific law, process, or context where applicable.
- Does not substantially repeat another FAQ's answer.
- Uses proper semantic HTML: paragraphs, lists, bold for key terms.

**Target range:** 500-1,500 words.

**Trigger a split review when:**

- The answer exceeds **1,500 words**, or
- It contains **5 or more H2 sections**.

**How to evaluate a split:** for each H2, apply the satisfaction test: "Would someone search for this H2 as a standalone question, and would they feel unsatisfied landing on this page's title?" If yes, that section likely deserves its own FAQ.

**When splitting:**

1. Extract the section into a new FAQ with its own id, slug, question, answer, short answer, and meta description.
2. In the original, replace the removed section with one sentence and a cross-reference link.
3. Cross-link both directions (each lists the other as related).
4. Update the intent registry and log the split.

**Do NOT split when:**

- It is a comparison ("A vs. B") that needs 800-1,200 words to treat both sides fairly.
- It is a sequential process explainer that reads better as one flow.
- Removing the section would leave the original under 500 words (too thin).

---

## 7. Structured Data & Metadata Fields

Most FAQ systems carry hidden fields for search engines and AI. Keep them consistent with the visible answer, and never display the machine-only ones.

### Short answer: structured data only, never displayed

- 1-2 sentences that directly answer the question.
- Optimized for AI citation and featured-snippet extraction.
- Under ~200 characters.
- It is fine if it overlaps the intro paragraph. They serve machines vs. humans. **Never render it on the page** (it duplicates the intro and looks redundant).

### Meta description: meta tags only, never displayed

- 150-160 characters, written as a compelling search-result snippet.
- Include the primary keyword and (where relevant) the geo qualifier.

### Related items: cross-linking

- Cross-link to sibling FAQs, definitions, and guides by stable **ID**, not by URL slug (slugs change; IDs should not).

### Keep them in sync

These fields do **not** auto-update when the body changes. Any time you edit the answer, re-review the short answer and meta description so they still match.

---

## 8. The Enhancement Path (preferred over new pages)

When new material overlaps an existing FAQ, make the existing page **richer** instead of spawning a competitor.

1. Open the existing FAQ.
2. Add the new material as a new `<h2>` subsection inside the existing answer.
3. The subsection should: have a clear descriptive heading, add genuine depth (not restate what is there), match the existing tone and reading level, and include region-specific detail where relevant.
4. Update the plain-text answer field to include a brief summary of the new subsection.
5. Set an `updatedDate` to today (`YYYY-MM-DD`). **Never change the original `publishedDate`.**
6. Log the enhancement in the intent registry.

```html
<p>[Existing answer paragraphs...]</p>

<h2>[New, More Specific Subtopic]</h2>
<p>[New content that adds depth, not repetition...]</p>
```

---

## 9. Writing Style (portable defaults)

Adapt the voice to `[YOUR BRAND]`, but these mechanics travel well to any FAQ:

- **Plain, straightforward language.** No jargon without a plain-English explanation first.
- **Full, complete sentences** in a conversational register. This mirrors how people search and how AI parses.
- **Short, definitive statements.** Every sentence says one thing. Cut filler and hedging.
- **Layer the explanation:** open with the plain-English summary, add the detail that makes it real, close with what it means for the reader.
- **Lead with the answer.** Do not bury it under setup. Answer the question in the first paragraph, then expand.
- **Treat readers as informed adults.** No condescension, no hype, no hard sell.
- **Link internally first.** If you have a glossary, guide, or service page for a concept, link there before citing an external source. External links enrich; they do not replace internal ones.
- **One concept, one link.** Link a term on first mention, then use plain text. Keep anchor text descriptive, never "click here."
- **Avoid em dashes.** Use periods, commas, or rewrite. Short sentences beat long ones stitched with dashes.

---

## 10. Final Review Gate (sign-off checklist)

Before publishing any FAQ, confirm every box:

- [ ] **One intent.** Passes the satisfaction test against existing pages.
- [ ] **Right format.** An FAQ is genuinely the correct container (not a glossary entry or a guide).
- [ ] **No cannibalization.** The primary keyword cluster is owned by this page or it links to the canonical owner.
- [ ] **Title.** Natural question format, front-loaded topic, geo qualifier if needed, under ~70 chars, covers the whole answer.
- [ ] **Depth.** At least 500 words of specific, useful content; within the 500-1,500 target or consciously justified.
- [ ] **No oversized page.** If over 1,500 words or 5+ H2s, a split review was done.
- [ ] **Structured data.** Short answer and meta description written, in sync with the body, and not rendered on the page.
- [ ] **Cross-links.** Related FAQs, definitions, and guides linked by stable ID, both directions.
- [ ] **Style.** Answer-first, plain language, internal links first, no em dashes.
- [ ] **Registry updated.** Intent registry and keyword ownership map reflect this page.
- [ ] **Dates.** `publishedDate` set on creation; `updatedDate` set on every later edit (publishedDate never changes).
