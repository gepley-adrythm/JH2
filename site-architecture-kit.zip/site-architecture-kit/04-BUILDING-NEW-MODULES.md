# Building New Business Modules

Once the core is healthy (the site shell in `01-SITE-STRUCTURE.md`, the SEO engine in `02-SEO-ARCHITECTURE.md`, and the three content modules Blog, FAQ, Glossary in `03-CORE-CONTENT-MODULES.md`), you can grow into business-specific modules. This file is the playbook for doing that **without** fragmenting the authority you have built.

The principle: **the core is universal, modules are specific.** Blog, FAQ, and Glossary work for any business. What you add on top is where your business gets specific, and every business is different. A law firm adds a statute library and case-law explainers. An e-commerce store adds product collections and buying guides. A SaaS adds docs, changelogs, and integration pages. A local service adds location pages. The *modules* differ; the *way you build them* does not.

Replace bracketed placeholders with your own.

---

## The gate: do not build modules too early

Build a business-specific module only when **all** of these are true:

- The site shell is live (Home, Services, About, Contact).
- The three core content modules exist and are interlinking (you have at least a few pillars, a growing FAQ, and a glossary).
- You have a **content intent registry** running, so you can check new content against existing content.
- The new module answers a real, recurring need that the core formats genuinely cannot serve well.

If a "new module" idea is really just a definition, a question, or a guide, it is not a module. It is a glossary term, an FAQ, or a blog pillar. Use the format decision tree in `SEO-FAQ-QUALITY-STANDARDS.md` first. Only build a new module when the content has a **distinct structure, schema, and route pattern** that the core does not provide.

---

## When does something deserve its own module?

A new module is justified when the content type has its own:

- **Distinct data shape**: fields that do not fit a blog post, FAQ, or glossary term (e.g. a statute has a citation, an effective date, and cross-references; a product has a price, variants, and stock).
- **Distinct schema.org type**: it maps to a structured-data type the core modules do not emit (e.g. `Product`, `Event`, `JobPosting`, `Recipe`, `HowTo`, `SoftwareApplication`).
- **Distinct route pattern**: it needs its own `/[module]` hub and `/[module]/[slug]` detail pattern.
- **Distinct user job**: people come to it to do something the core does not serve (compare products, look up a law, find a location, use a tool).

If it has all four, it is a module. If it has none, it is core content. If it has some, think harder before adding surface area.

---

## The module recipe (repeat for every new module)

Every well-built module follows the same six-part pattern. This is the heart of this guide.

### 1. Single source of truth (data)
Put all the module's records in **one** place, a seed file or CMS collection, with a typed shape. Every record gets a stable `id` and a `slug`. Define the fields once and let routes, sitemaps, navigation, and internal links all read from it. Never duplicate the list across components.

### 2. Routes (hub + detail)
Add a hub page (`/[module]`) that lists, searches, and filters the records, and a detail page (`/[module]/[slug]`) for each record. Mirror the conventions in `01-SITE-STRUCTURE.md`: lowercase hyphenated slugs, breadcrumbs, one canonical URL each.

### 3. Structured data
Pick the right schema.org type for the module and emit it on the detail pages (and a list/collection type on the hub if one fits). Follow the cardinal rule from `02-SEO-ARCHITECTURE.md`: **never duplicate a `@type` the layout already emits.**

### 4. Metadata
Unique title and meta description per page, the canonical URL, Open Graph tags, and one H1. Wire the module into your centralized SEO-overrides map so titles stay tunable.

### 5. Internal linking into the core (the most important step)
A module that does not link into the core is an island that adds nothing to your authority. Every new module must:
- **Link up** to the relevant blog pillar and **across** to related FAQs and glossary terms (by ID, not pasted URL).
- **Be linked to** from the core. Add `relatedXIds` references from the relevant service pages, pillars, and FAQs back to the module's records.
- **Cross-link siblings** within the module.
- **Appear in navigation**, at minimum the footer, and the Resources hub or Services area if it fits there.

### 6. Technical SEO wiring
Add the module's URLs to the sitemap generator, confirm `robots.txt` allows them, add any needed redirects, and (if relevant) include the module in `llms.txt`. Register every new record in the **content intent registry** so it cannot cannibalize existing pages.

> If you skip step 5, the module will underperform and may even compete with your core pages for the same keywords. Internal linking is not optional polish. It is the reason the module ranks.

---

## Example module shapes (illustrative, not prescriptive)

These show how the recipe maps to different businesses. Yours will differ; the pattern does not.

- **Reference library** (laws, standards, specs): records with citations and effective dates, `/[library]/[slug]` pages, cross-linked to the pillars and FAQs that explain them in plain language. Schema: a domain-appropriate type plus `Article` for the explainer.
- **Product catalog** (e-commerce): records with price, variants, images, and stock; `Product`/`Offer` schema; buying-guide pillars (blog) and product-question FAQs link into each product, and products link back to their guides.
- **Directory / locations** (local or multi-location): one genuinely-local page per place, `LocalBusiness` schema per location, linked from a `/locations` hub and from relevant services.
- **Events / classes (OPTIONAL, most sites will not need this)**: records with dates and venues, `Event` schema, linked from the relevant service and promoted on the home page. Treat events as a fully optional module. Most businesses using this kit do not run events, so do not scaffold an events system, route, or schema unless the business actually holds events and wants them on the site. The same shape, a list of dated or numbered records with a hub and a detail page, repurposes cleanly for other "list of items" needs: product listings, property or inventory listings, job openings, webinars, appointment slots, or a release timeline. If you need a listing like that, reuse this pattern and swap `Event` for the schema that fits (`Product`, `JobPosting`, and so on). If you do not, skip it entirely.
- **Interactive tools** (calculators, checklists, configurators): a `/tools` hub and a page per tool; these earn engagement and backlinks, and each tool links to the pillar and service it supports.
- **Case studies / portfolio**: proof content with results; `Article` or a review/rating type; linked from the relevant service pages to lift conversion.
- **Careers**: job postings with `JobPosting` schema under `/careers`, linked from About.

In every case: one data source, hub + detail routes, the right schema, clean metadata, links woven into the core, and sitemap/registry wiring.

---

## Sequencing your growth

A reliable order for a content-driven site:

1. **Shell**: Home, Services, About, Contact (`01-SITE-STRUCTURE.md`).
2. **Glossary**: establish vocabulary.
3. **Blog pillars**: own your major topics.
4. **FAQ clusters**: capture the long tail; keep this growing forever.
5. **First business module**: the one that most directly supports conversion (often a tool, a catalog, or location pages).
6. **Additional modules**: added one at a time, each fully wired into the core before starting the next.

Resist building several modules at once. A half-wired module (no internal links, no schema, no sitemap entries) is worse than no module, because it dilutes crawl budget and can cannibalize your core. Finish the recipe for each module before moving on.

---

## A checklist before you ship any new module

- [ ] It genuinely needs its own data shape, schema, route, and user job (not just core content in disguise).
- [ ] All records live in one typed source of truth, each with an `id` and `slug`.
- [ ] Hub page (list/search/filter) and detail pages exist, with breadcrumbs and clean URLs.
- [ ] Correct schema.org type emitted; no duplicate `@type` with the layout.
- [ ] Unique title, meta description, canonical, OG tags, single H1 per page.
- [ ] Linked **into** the core (up to pillars, across to FAQs/glossary) and linked **from** the core back to it.
- [ ] Added to sitemap, allowed in robots, redirects in place, included in `llms.txt` if used.
- [ ] Every record registered in the content intent registry; checked for overlap.
- [ ] Appears in navigation (footer at minimum).

When every box is checked, the module strengthens the whole site instead of fragmenting it. That is the difference between a site that grows more authoritative with every addition and one that slowly turns into a pile of disconnected pages.
