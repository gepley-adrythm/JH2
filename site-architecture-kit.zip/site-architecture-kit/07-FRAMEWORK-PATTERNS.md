# Framework Patterns and Gotchas

This is the doc that saves a new agent (or a new engineer) the most time. It
collects the **rendering and SEO patterns** that make a content site actually
rank, plus the **recurring gotchas** that quietly break them. The patterns are
framework-agnostic; the examples use a modern React/App-Router style because that
is what the kit's `components/` ship in, but each one maps to any SSR-capable
framework.

Read `05-FRAMEWORKS.md` (rendering models) and `06-BACKEND-AND-STACK.md` (the
stack) first. This doc assumes you have chosen SSG/ISR/SSR per page and stood up
the data layer.

---

## The one rule everything serves

> **Every indexable page must ship complete, meaningful HTML on the first
> response.** If you remember nothing else, remember this. Every pattern below
> exists to protect it.

After any change to an indexable page, **verify the raw HTML** before trusting
it. Fetch the route as a crawler would and confirm the real content (the H1, the
body copy) is in the response, not just an empty shell that fills in after
JavaScript:

```bash
curl -s https://[YOUR DOMAIN]/[SOME PAGE] | grep -i "<h1"
```

If the meaningful content is missing from that output, the page is rendering
client-side and will not rank, no matter how good it looks in a browser.

---

## 1. The server-rendered H1 pattern

Crawlers need exactly one `<h1>` present in the initial HTML. In frameworks that
split server and client components, the visible heading often lives in an
interactive client component that may render late. The fix:

- Render an accessible `sr-only` `<h1>` in the **server component** (the page
  itself), before any client/`Suspense` boundary, so it is always in the first
  HTML response.
- Render the **visual** heading inside the client component as a styled
  `<div aria-hidden="true">`, **not** a second `<h1>`, so you do not ship two
  headings.

This guarantees one crawlable H1 in initial HTML and a styled heading for users,
with no duplication. Apply it to every detail and landing page.

---

## 2. Do not let a client library collapse the page into CSR

This is the subtle one. A page can be authored as server-rendered and still ship
an **empty body** to crawlers if a client-side library trips the framework's
"this needs to be dynamic" detection during prerender. Data-fetching, animation,
date/time, and randomness libraries are common culprits because they touch
non-deterministic APIs during render.

Defenses:

- **Verify, do not assume.** Use the `curl` check above on real pages after
  adding any client library that runs during render. An empty `<body>` or a
  missing H1 is the signature of an accidental CSR fall-back.
- **Push non-determinism out of render.** Read the current time, random values,
  or browser-only APIs inside effects or event handlers, not in the render path
  of a server-rendered tree.
- **Guard browser-only APIs** in any component that can render on the server:
  check `typeof window !== 'undefined'` before touching `window`, `document`, or
  `localStorage`.
- If a specific library is known to interfere with your framework's prerender
  pass, isolate it behind a client boundary or apply the framework's documented
  workaround. The lesson that generalizes: **a green build is not proof the page
  rendered; the HTML output is.**

---

## 3. Client boundaries and payload discipline

In server-component frameworks, everything server-rendered is serialized and sent
to the client to hydrate. Large server trees mean large payloads and slower
loads.

- Mark genuinely interactive, leaf-heavy pieces (footers, ambient backgrounds,
  carousels) as **client components** so their DOM is not fully serialized into
  the server payload; the client builds them instead.
- **Trim data before it crosses to the client.** A list page does not need to
  send every field of every record. Send what the list renders; fetch detail on
  the detail page.
- Prefetch only **above-the-fold and SEO-critical** data on the server. Let
  below-the-fold sections fetch client-side after load. This keeps the initial
  payload lean without hurting what crawlers see.

The goal is the smallest first response that still contains all the indexable
content.

---

## 4. Async dynamic request APIs

Modern frameworks have moved per-request inputs to **async** access. Route
parameters, search params, cookies, and headers are commonly `Promise`-wrapped
and must be awaited:

```tsx
// WRONG (older synchronous style, fails on current versions)
export default function Page({ params }: { params: { slug: string } }) {
  return <h1>{params.slug}</h1>;
}

// CORRECT
export default async function Page(props: { params: Promise<{ slug: string }> }) {
  const { slug } = await props.params;
  return <h1>{slug}</h1>;
}
```

The exact API surface and whether these inputs are async is framework- and
version-specific, so confirm the convention for your version rather than copying
this snippet verbatim. The same principle applies to metadata generation and to
any route handler reading cookies or headers. When you upgrade a framework major
version, this is one of the first things to break; check the upgrade notes and
run the official codemod if one exists.

---

## 5. Version-churn gotchas (check on every upgrade)

Frameworks rename and re-default things between majors. These bite agents who
assume yesterday's API:

- **Routing/middleware files get renamed.** A file that intercepts requests
  (redirects, security headers, rate limiting) may change name or supported
  runtime between versions. Do not keep two competing files; follow the current
  convention.
- **Bundler defaults change.** A new default bundler may ignore your old custom
  build config. Either migrate to the new equivalents or explicitly opt back in.
- **Image defaults change.** Default cache lifetimes, allowed quality values, and
  responsive size arrays shift between versions. Set the ones you depend on
  **explicitly** so a default change does not silently alter output.
- **Caching/revalidation APIs get renamed** (often dropping experimental
  prefixes). Use the current names for time-based and tag-based revalidation.

Before relying on any framework feature, confirm it exists in **your** version.
A remembered API is a claim about the past; grep your lockfile and the current
docs before trusting it.

---

## 6. Caching and revalidation (making ISR work)

If you chose ISR for a content set (`05-FRAMEWORKS.md`), wire revalidation
deliberately:

- Give cacheable data **time-based revalidation** (rebuild every N seconds/hours)
  for content that drifts slowly.
- Use **tag-based revalidation** to invalidate exactly the pages affected when a
  specific record changes, instead of rebuilding the whole site.
- After a content edit, confirm the page actually regenerated (re-run the `curl`
  check) rather than assuming the cache cleared.

The win is static-page speed with the freshness of a dynamic site, but only if
the revalidation is actually hooked up.

---

## 7. Structured data must stay unique

Pull the full rules from `02-SEO-ARCHITECTURE.md`; the load-bearing one to keep
in working memory:

> **Never emit the same schema.org `@type` twice on one page.** Layouts usually
> inject site-wide types (Organization, and a business type). Page-level blocks
> add page-specific types. Before adding any JSON-LD, check what the parent
> layout already emits so you do not duplicate it.

Duplicate types are a common, silent structured-data error that suppresses rich
results.

---

## 8. Build-failure prevention checklist

Run through this before shipping any change to a server-rendered app:

- [ ] **Interface changes are propagated.** If you changed a component's props,
      grep every caller and update all of them. A missed caller fails the build.
- [ ] **Per-request inputs are awaited** (params, searchParams, cookies, headers)
      in every page, layout, and metadata function (section 4).
- [ ] **Browser-only APIs are guarded** behind `typeof window !== 'undefined'`
      in anything that can render on the server (section 2).
- [ ] **Server-only code stays server-side.** Never import server modules
      (database, secrets, file system) into a client component.
- [ ] **No unused side-effecting imports.** Strict mode and modern bundlers flag
      them.
- [ ] **Images go through the loader/component**, not hand-written CDN URLs
      (`06-BACKEND-AND-STACK.md`).
- [ ] **One H1 in initial HTML**, server-rendered (section 1).
- [ ] **No duplicate JSON-LD `@type`** with the layout (section 7).
- [ ] **The raw HTML was verified** with `curl` for any indexable page touched
      (top of this doc).

---

## 9. How this connects to the rest of the kit

- `01-SITE-STRUCTURE.md` and `04-BUILDING-NEW-MODULES.md` define the routes these
  patterns render.
- `02-SEO-ARCHITECTURE.md` owns metadata, canonical URLs, sitemaps, and the full
  structured-data rules summarized in section 7.
- `05-FRAMEWORKS.md` chose the rendering model per page; this doc keeps that
  choice honest at the code level.
- `06-BACKEND-AND-STACK.md` set up the data and media layers these pages read
  from.
- `components/` ship a working header that already follows the client-boundary
  and accessibility patterns above.

The thread through all of it: pick the rendering model, build the stack to
support it, and then protect the "real HTML on first response" guarantee in every
component you write.
