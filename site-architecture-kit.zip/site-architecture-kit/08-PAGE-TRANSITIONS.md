# Smooth Page Transitions

A site can ship perfect HTML (`07-FRAMEWORK-PATTERNS.md`) and still feel cheap if
navigation is abrupt: a white flash, a hard content swap, the new page inheriting
the old scroll position. This doc covers the transition system that makes
navigation feel deliberate and calm, and ships the real, brand-agnostic code for
it in `components/`.

The trap to avoid: smooth transitions are not one big animation. They are a few
small, cooperating pieces, each removing one specific source of jank. Build them
as layers.

---

## The mental model: smooth is the absence of jank

"Smooth" is what you get when you remove every jarring thing, in this order of
impact:

1. **No white flash between routes** (paint the right background instantly).
2. **A gentle cross-fade** from the old page to the new one.
3. **Scroll resets to the top** on navigation so the new page starts clean.
4. **Content eases in** in a short, staggered sequence rather than snapping.
5. **In-page view switches** (tabs, filters) animate instead of cutting.

And one rule that wraps all five: **respect reduced motion.** If the visitor asked
their OS to reduce motion, every animation becomes an instant, motionless state
change. This is not optional polish; it is an accessibility requirement.

---

## Layer 1: kill the white flash (route background)

This is the single highest-impact, least-obvious piece. During navigation there
is a brief gap where the old page is gone and the new one has not painted. If the
default background is white, you get a flash on every click, which makes even a
flawless cross-fade look like strobing.

Fix it by painting the correct per-route background onto `<html>` **before**
content hydrates, driven by the current path:

- `components/routeBackground.ts`: a config map of path prefix to background
  color, with a `getRouteBg()` longest-prefix lookup. This is your one rebrand
  surface for backgrounds.
- `components/RouteBackground.tsx`: a tiny client component that reads the path
  and writes the color into a `--route-bg` CSS variable.

Wire it once in your root layout and apply the variable on `<html>`:

```tsx
// root layout
<html style={{ backgroundColor: 'var(--route-bg, #0b1c33)' }}>
  <body>
    <RouteBackground />
    {children}
  </body>
</html>
```

Do this first. It does more for perceived smoothness than the fade itself.

---

## Layer 2: the cross-route fade (View Transitions API)

Use the browser's **native View Transitions API** rather than wrapping every page
in an animation component. The browser snapshots the outgoing and incoming page
and cross-fades them for you. It is less code, it does not bloat your client
bundle, and it degrades gracefully (no support means an instant swap, which is
fine).

Two steps:

1. **Opt in at the framework level.** In Next.js App Router this is a config flag
   (`experimental: { viewTransition: true }`, or the stable flag for your
   version). Other frameworks expose similar hooks; some browsers do it
   automatically for same-document navigations.
2. **Style the fade in CSS** (shipped in `components/transitions.css`):

```css
::view-transition-old(root) { animation-name: vt-fade-out; }
::view-transition-new(root) { animation-name: vt-fade-in; }
@keyframes vt-fade-out { from { opacity: 1; } to { opacity: 0; } }
@keyframes vt-fade-in  { from { opacity: 0; } to { opacity: 1; } }
```

Keep the cross-fade short and subtle. A slow page fade feels sluggish, not
premium. The fade is the supporting actor; the content entrance (Layer 4) is the
star.

> Why not animate every route with a JavaScript wrapper (for example a motion
> component in a `template` file)? You can, but it ships more code, fights the
> framework's streaming/Suspense rendering, and is easy to get wrong in ways that
> hurt the "real HTML on first response" rule from `07-FRAMEWORK-PATTERNS.md`.
> The native API is the lighter, safer default. Reach for a JS wrapper only when
> you need shared-element transitions the CSS API cannot express.

---

## Layer 3: reset scroll on navigation

A client-side navigation can leave the new page scrolled to wherever the old one
was. `components/ScrollToTop.tsx` fixes this: it scrolls to the top on a real path
change (not on every render), so in-page hash/anchor changes are left alone. Mount
it once in the root layout next to `RouteBackground`.

One honest caveat: because it fires on any path change, it also scrolls to top on
back/forward navigation to a different route, which overrides the browser's native
scroll restoration. That is usually the behavior you want. If you need to preserve
scroll on back/forward, gate the scroll on a forward navigation (skip it when a
`popstate` event fired since the last render). The component comment notes this.

---

## Layer 4: staggered content entrance

This is the part people actually notice. Instead of the page appearing all at
once, the hero elements rise in over a few hundred milliseconds, each slightly
after the last, so the headline assembles itself.

Two ways to drive it, both using one shared easing curve,
`cubic-bezier(0.22, 1, 0.36, 1)` (the `EASE_OUT_EXPO` token in
`components/motion.ts`):

- **CSS, for above-the-fold hero content** that should animate on load. Add the
  `hero-eyebrow` / `hero-title` / `hero-subtitle` / `hero-cta` classes from
  `transitions.css`; the staggered delays are built in.
- **JavaScript, for below-the-fold sections** that should animate when they
  scroll into view. Use `FADE_IN_UP_PROPS` from `motion.ts` with Framer Motion's
  `whileInView` so the reveal fires on scroll, not on load.

The discipline that makes this feel designed rather than busy: **one easing
curve, a small set of durations (roughly 0.3s to 0.8s), and short offsets.** Do
not give every element a different curve or a long delay. Cohesion beats variety.

---

## Layer 5: in-page view switches

When a tab, filter, or sub-page changes content without a full navigation, animate
the swap so it does not cut. Use Framer Motion's `AnimatePresence` with
`mode="wait"`, keyed on the active view, and the `TAB_SWITCH_PROPS` token:

```tsx
import { AnimatePresence, m } from 'framer-motion';
import { TAB_SWITCH_PROPS } from './motion';

<AnimatePresence mode="wait">
  <m.div key={activeTab} {...TAB_SWITCH_PROPS}>
    {panelForActiveTab}
  </m.div>
</AnimatePresence>
```

`mode="wait"` lets the outgoing panel finish exiting before the new one enters, so
the two never overlap awkwardly. Load Framer Motion lazily (a `LazyMotion`
provider with `m` components instead of `motion`) so this interactivity does not
ship a full animation runtime to pages that do not use it.

---

## What ships in `components/`

| File | Role | Rebrand surface |
| --- | --- | --- |
| `routeBackground.ts` | Path-to-background map plus `getRouteBg()` | Edit `DEFAULT_BG` and `ROUTE_BG` |
| `RouteBackground.tsx` | Writes `--route-bg` per route (Layer 1) | none |
| `ScrollToTop.tsx` | Scroll reset on navigation (Layer 3) | none |
| `transitions.css` | View Transitions fade, hero entrance, fade-in-up, progress bar, reduced-motion guards (Layers 2, 4) | colors via `--accent`, delays/durations inline |
| `motion.ts` | Shared easing and motion tokens for JS-driven entrance and tab switches (Layers 4, 5) | `EASE_OUT_EXPO`, durations |

All class names and tokens are generic. There are no brand strings; colors come
from config or CSS variables, not hardcoded values in components.

---

## Putting it together (Next.js App Router)

```tsx
// app/layout.tsx
import './globals.css';
import './transitions.css'; // or import transitions.css from components/
import RouteBackground from './RouteBackground';
import ScrollToTop from './ScrollToTop';

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" style={{ backgroundColor: 'var(--route-bg, #0b1c33)' }}>
      <body>
        <RouteBackground />
        <ScrollToTop />
        {children}
      </body>
    </html>
  );
}
```

Enable view transitions in `next.config`, then add the hero classes to your
landing pages and `AnimatePresence` to your tabbed sections. That is the full
system.

---

## Porting to another framework

Nothing here is deeply Next-specific:

- `RouteBackground.tsx` and `ScrollToTop.tsx` only need a **current-path hook**;
  swap `usePathname` for your framework's equivalent.
- `transitions.css` is plain CSS and works anywhere; the View Transitions API is
  a browser feature, not a framework one. The catch is the trigger: a transition
  only happens if something calls `document.startViewTransition()` around the DOM
  update. How that gets wired varies by framework. Next.js gates it behind a
  config flag, some routers expose an opt-in option, and others require you to
  call it yourself in your navigation handler. Do not assume it is automatic;
  check how your router triggers view transitions and confirm the fade actually
  fires before relying on it.
- `motion.ts` values port to any animation library; only the prop shapes assume
  Framer Motion.

---

## Checklist

- [ ] Per-route background is painted on `<html>` before content (no white flash).
- [ ] View transitions are enabled in framework config and styled in CSS.
- [ ] Scroll resets to top on real navigations only.
- [ ] Hero content uses the staggered entrance classes; below-fold sections use
      scroll-triggered reveals.
- [ ] One easing curve and a small set of durations across all motion.
- [ ] In-page tab/filter switches use `AnimatePresence mode="wait"`.
- [ ] Every animation is disabled under `prefers-reduced-motion`.
- [ ] Framer Motion is loaded lazily so static pages stay light.
